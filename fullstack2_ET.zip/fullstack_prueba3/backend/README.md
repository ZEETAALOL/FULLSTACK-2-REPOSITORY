# Level-Up Gamer - Backend API

Backend API REST para la plataforma e-commerce Level-Up Gamer, construida con Node.js, Express y SQLite.

## 🚀 Tecnologías

- **Node.js** - Runtime de JavaScript
- **Express 5.2** - Framework web
- **Sequelize** - ORM para base de datos
- **SQLite** - Base de datos (fácil de cambiar a PostgreSQL/MySQL)
- **JWT (jsonwebtoken)** - Autenticación basada en tokens
- **bcryptjs** - Hash de contraseñas
- **CORS** - Middleware para habilitar CORS
- **dotenv** - Variables de entorno

## 📁 Estructura del Proyecto

```
backend/
├── src/
│   ├── config/
│   │   └── database.js          # Configuración de Sequelize
│   ├── controllers/
│   │   ├── authController.js    # Login, registro, perfil
│   │   ├── usuariosController.js # CRUD de usuarios (admin)
│   │   ├── productosController.js# CRUD de productos
│   │   ├── categoriasController.js # CRUD de categorías
│   │   └── comprasController.js # Gestión de compras
│   ├── middlewares/
│   │   ├── auth.js              # Autenticación y autorización
│   │   └── errorHandler.js      # Manejo global de errores
│   ├── models/
│   │   ├── index.js             # Relaciones entre modelos
│   │   ├── Rol.js
│   │   ├── Usuario.js
│   │   ├── Categoria.js
│   │   ├── Producto.js
│   │   ├── Compra.js
│   │   ├── DetalleCompra.js
│   │   └── Resena.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── usuarios.js
│   │   ├── productos.js
│   │   ├── categorias.js
│   │   └── compras.js
│   ├── seeders/
│   │   └── seed.js              # Datos iniciales
│   └── app.js                   # Configuración principal
├── .env                         # Variables de entorno
├── package.json
└── database.sqlite              # Base de datos (se crea automáticamente)
```

## ⚙️ Instalación

1. Instalar dependencias:
```bash
npm install
```

2. Configurar variables de entorno (`.env` ya está creado con valores por defecto)

3. Crear base de datos y poblar con datos iniciales:
```bash
npm run seed
```

4. Iniciar servidor:
```bash
npm start          # Producción
npm run dev        # Desarrollo (con nodemon)
```

El servidor estará corriendo en `http://localhost:5000`

## 📊 Modelo de Base de Datos

### Tablas y Relaciones

```
roles (admin, cliente)
  ↓
usuarios (nombre, correo, password, puntos_fidelidad, rol_id)
  ↓
compras (total, descuentos, direccion_envio, usuario_id)
  ↓
detalle_compras (cantidad, precio_unitario, compra_id, producto_id)

categorias (nombre, descripcion)
  ↓
productos (nombre, precio, stock, img, categoria_id)
  ↓
resenas (calificacion, comentario, producto_id, usuario_id)
```

## 🔐 Autenticación

La API usa JWT (JSON Web Tokens) para autenticación:

1. **Login**: Envía credenciales → Recibe token JWT
2. **Requests protegidos**: Incluye token en header `Authorization: Bearer <token>`
3. **Roles**: `admin` (acceso total) y `cliente` (acceso limitado)

## 📡 Endpoints de la API

### Base URL: `http://localhost:5000/api`

---

### 🔑 Autenticación (`/api/auth`)

#### `POST /auth/register`
Registrar nuevo usuario

**Body:**
```json
{
  "nombre": "Juan",
  "apellidos": "Pérez",
  "correo": "juan@ejemplo.com",
  "password": "password123",
  "telefono": "+56912345678",
  "direccion": "Calle Ejemplo 123"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Usuario registrado exitosamente",
  "data": {
    "usuario": { ... },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6..."
  }
}
```

---

#### `POST /auth/login`
Iniciar sesión

**Body:**
```json
{
  "correo": "admin@gmail.com",
  "password": "admin123"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Login exitoso",
  "data": {
    "usuario": {
      "id": 1,
      "nombre": "Admin",
      "correo": "admin@gmail.com",
      "rol": {
        "id": 1,
        "nombre": "admin"
      }
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6..."
  }
}
```

---

#### `GET /auth/me`
Obtener perfil del usuario autenticado

**Headers:** `Authorization: Bearer <token>`

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "nombre": "Admin",
    "correo": "admin@gmail.com",
    "puntos_fidelidad": 0,
    "rol": { "nombre": "admin" }
  }
}
```

---

### 👥 Usuarios (`/api/usuarios`) - Solo Admin

#### `GET /usuarios`
Obtener todos los usuarios

**Headers:** `Authorization: Bearer <token>` (Admin)

**Respuesta:**
```json
{
  "success": true,
  "count": 2,
  "data": [ ... ]
}
```

---

#### `GET /usuarios/:id`
Obtener un usuario específico

---

#### `PUT /usuarios/:id`
Actualizar usuario

**Body:**
```json
{
  "nombre": "Nuevo Nombre",
  "puntos_fidelidad": 1000,
  "rol_id": 2
}
```

**Nota:** El usuario admin@gmail.com está protegido y no puede ser editado.

---

#### `DELETE /usuarios/:id`
Eliminar usuario

**Nota:** El usuario admin@gmail.com está protegido y no puede ser eliminado.

---

### 📦 Productos (`/api/productos`)

#### `GET /productos`
Obtener todos los productos (Público)

**Query params opcionales:**
- `categoria_id`: Filtrar por categoría
- `destacado`: `true` o `false`

**Respuesta:**
```json
{
  "success": true,
  "count": 12,
  "data": [
    {
      "id": 1,
      "nombre": "PlayStation 5",
      "descripcion": "Consola de última generación...",
      "precio": 499990,
      "stock": 15,
      "img": "https://...",
      "destacado": true,
      "categoria": {
        "id": 1,
        "nombre": "Consolas"
      },
      "resenas": []
    }
  ]
}
```

---

#### `GET /productos/:id`
Obtener un producto específico (Público)

---

#### `POST /productos`
Crear producto (Admin)

**Headers:** `Authorization: Bearer <token>` (Admin)

**Body:**
```json
{
  "nombre": "Producto Nuevo",
  "descripcion": "Descripción del producto",
  "precio": 99990,
  "stock": 10,
  "img": "https://ejemplo.com/imagen.jpg",
  "categoria_id": 1,
  "destacado": false
}
```

---

#### `PUT /productos/:id`
Actualizar producto (Admin)

---

#### `DELETE /productos/:id`
Eliminar producto (Admin)

---

### 🏷️ Categorías (`/api/categorias`)

#### `GET /categorias`
Obtener todas las categorías (Público)

**Respuesta:**
```json
{
  "success": true,
  "count": 5,
  "data": [
    {
      "id": 1,
      "nombre": "Consolas",
      "descripcion": "Consolas de videojuegos...",
      "productos": [ ... ]
    }
  ]
}
```

---

#### `GET /categorias/:id`
Obtener una categoría específica

---

#### `POST /categorias`
Crear categoría (Admin)

**Body:**
```json
{
  "nombre": "Nueva Categoría",
  "descripcion": "Descripción de la categoría"
}
```

---

#### `PUT /categorias/:id`
Actualizar categoría (Admin)

---

#### `DELETE /categorias/:id`
Eliminar categoría (Admin)

**Nota:** No se puede eliminar si tiene productos asociados.

---

### 🛒 Compras (`/api/compras`)

#### `POST /compras`
Crear nueva compra (Autenticado)

**Headers:** `Authorization: Bearer <token>`

**Body:**
```json
{
  "productos": [
    {
      "producto_id": 1,
      "cantidad": 2,
      "precio_unitario": 499990
    },
    {
      "producto_id": 4,
      "cantidad": 1,
      "precio_unitario": 39990
    }
  ],
  "total": 1039970,
  "descuento_duoc": 0,
  "descuento_puntos": 0,
  "direccion_envio": "Av. Ejemplo 123, Santiago"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Compra realizada exitosamente",
  "data": {
    "compra": { ... },
    "puntos_ganados": 1039
  }
}
```

**Nota:** Actualiza automáticamente el stock y suma puntos de fidelidad (1 punto por cada $1000).

---

#### `GET /compras/mis-compras`
Obtener mis compras (Autenticado)

**Headers:** `Authorization: Bearer <token>`

---

#### `GET /compras`
Obtener todas las compras (Admin)

**Headers:** `Authorization: Bearer <token>` (Admin)

---

#### `GET /compras/:id`
Obtener una compra específica (Autenticado)

**Nota:** Solo el dueño de la compra o un admin puede verla.

---

## 🧪 Datos de Prueba

Después de ejecutar `npm run seed`, se crean:

### Usuarios:
- **Admin:** `admin@gmail.com` / `admin123`
- **Cliente:** `juan@duocuc.cl` / `cliente123` (tiene 500 puntos de fidelidad)

### Categorías:
1. Consolas
2. Videojuegos
3. Accesorios
4. PC Gaming
5. Merchandising

### Productos:
12 productos de ejemplo con imágenes, stock y precios

---

## 🔒 Seguridad

- ✅ Passwords hasheados con bcryptjs (salt rounds: 10)
- ✅ JWT con expiración de 7 días
- ✅ Validación de roles (admin/cliente)
- ✅ Protección del usuario admin principal
- ✅ Validación de stock antes de comprar
- ✅ Transacciones en compras (rollback en caso de error)
- ✅ Headers de seguridad con CORS

---

## 🚨 Códigos de Estado HTTP

- `200` - OK
- `201` - Created
- `400` - Bad Request (validación fallida)
- `401` - Unauthorized (sin token o token inválido)
- `403` - Forbidden (sin permisos)
- `404` - Not Found
- `500` - Internal Server Error

---

## 📝 Formato de Respuestas

### Éxito:
```json
{
  "success": true,
  "message": "Mensaje descriptivo",
  "data": { ... }
}
```

### Error:
```json
{
  "success": false,
  "message": "Descripción del error"
}
```

---

## 🔄 Migrar a PostgreSQL/MySQL

Para cambiar de SQLite a PostgreSQL o MySQL:

1. Instalar el driver:
```bash
npm install pg pg-hstore    # PostgreSQL
# o
npm install mysql2          # MySQL
```

2. Actualizar `.env`:
```env
DB_DIALECT=postgres
DB_HOST=localhost
DB_PORT=5432
DB_NAME=levelup_gamer
DB_USER=tu_usuario
DB_PASSWORD=tu_password
```

3. Actualizar `src/config/database.js` para usar las nuevas variables.

---

## 📞 Soporte

Para más información sobre el proyecto, revisa el código fuente en los controladores y modelos.
