const express = require('express');
const router = express.Router();
const {
  obtenerCategorias,
  obtenerCategoria,
  crearCategoria,
  actualizarCategoria,
  eliminarCategoria
} = require('../controllers/categoriasController');
const { protect, authorize } = require('../middlewares/auth');

// Rutas públicas
router.get('/', obtenerCategorias);
router.get('/:id', obtenerCategoria);

// Rutas protegidas (solo admin)
router.post('/', protect, authorize('admin'), crearCategoria);
router.put('/:id', protect, authorize('admin'), actualizarCategoria);
router.delete('/:id', protect, authorize('admin'), eliminarCategoria);

module.exports = router;
