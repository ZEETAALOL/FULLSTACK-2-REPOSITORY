const express = require('express');
const router = express.Router();
const {
  obtenerUsuarios,
  obtenerUsuario,
  actualizarUsuario,
  eliminarUsuario
} = require('../controllers/usuariosController');
const { protect, authorize } = require('../middlewares/auth');

// Todas las rutas requieren autenticación y rol de admin
router.use(protect);
router.use(authorize('admin'));

router.get('/', obtenerUsuarios);
router.get('/:id', obtenerUsuario);
router.put('/:id', actualizarUsuario);
router.delete('/:id', eliminarUsuario);

module.exports = router;
