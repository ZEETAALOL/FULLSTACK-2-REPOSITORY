const express = require('express');
const router = express.Router();
const { registrar, login, obtenerPerfil } = require('../controllers/authController');
const { protect } = require('../middlewares/auth');

// Rutas públicas
router.post('/register', registrar);
router.post('/login', login);

// Rutas protegidas
router.get('/me', protect, obtenerPerfil);

module.exports = router;
