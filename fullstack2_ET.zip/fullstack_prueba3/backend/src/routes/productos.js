const express = require('express');
const router = express.Router();
const {
  obtenerProductos,
  obtenerProducto,
  crearProducto,
  actualizarProducto,
  eliminarProducto
} = require('../controllers/productosController');
const { protect, authorize } = require('../middlewares/auth');

// Rutas públicas
router.get('/', obtenerProductos);
router.get('/:id', obtenerProducto);

// Rutas protegidas (solo admin)
router.post('/', protect, authorize('admin'), crearProducto);
router.put('/:id', protect, authorize('admin'), actualizarProducto);
router.delete('/:id', protect, authorize('admin'), eliminarProducto);

module.exports = router;
