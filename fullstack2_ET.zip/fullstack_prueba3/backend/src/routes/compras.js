const express = require('express');
const router = express.Router();
const {
  crearCompra,
  obtenerMisCompras,
  obtenerTodasCompras,
  obtenerCompra
} = require('../controllers/comprasController');
const { protect, authorize } = require('../middlewares/auth');

// Todas las rutas requieren autenticación
router.use(protect);

// Rutas de cliente
router.post('/', crearCompra);
router.get('/mis-compras', obtenerMisCompras);
router.get('/:id', obtenerCompra);

// Rutas de admin
router.get('/', authorize('admin'), obtenerTodasCompras);

module.exports = router;
