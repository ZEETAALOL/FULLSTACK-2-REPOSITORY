const jwt = require('jsonwebtoken');
const { Usuario, Rol } = require('../models');

// Middleware para proteger rutas (requiere autenticación)
const protect = async (req, res, next) => {
  let token;

  // Verificar si el token viene en el header Authorization
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      // Obtener el token del header
      token = req.headers.authorization.split(' ')[1];

      // Verificar token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Obtener usuario del token (sin password)
      req.user = await Usuario.findByPk(decoded.id, {
        attributes: { exclude: ['password'] },
        include: [{ model: Rol, as: 'rol' }]
      });

      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Usuario no encontrado'
        });
      }

      next();
    } catch (error) {
      console.error('Error en autenticación:', error);
      return res.status(401).json({
        success: false,
        message: 'No autorizado, token inválido'
      });
    }
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'No autorizado, no hay token'
    });
  }
};

// Middleware para autorizar por rol
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'No autorizado'
      });
    }

    if (!roles.includes(req.user.rol.nombre)) {
      return res.status(403).json({
        success: false,
        message: `El rol ${req.user.rol.nombre} no tiene permiso para acceder a este recurso`
      });
    }

    next();
  };
};

module.exports = { protect, authorize };
