const { sequelize } = require('../config/database');
const Rol = require('./Rol');
const Usuario = require('./Usuario');
const Categoria = require('./Categoria');
const Producto = require('./Producto');
const Compra = require('./Compra');
const DetalleCompra = require('./DetalleCompra');
const Resena = require('./Resena');

// Definir relaciones

// Usuario - Rol (Many to One)
Usuario.belongsTo(Rol, { foreignKey: 'rol_id', as: 'rol' });
Rol.hasMany(Usuario, { foreignKey: 'rol_id', as: 'usuarios' });

// Producto - Categoria (Many to One)
Producto.belongsTo(Categoria, { foreignKey: 'categoria_id', as: 'categoria' });
Categoria.hasMany(Producto, { foreignKey: 'categoria_id', as: 'productos' });

// Compra - Usuario (Many to One)
Compra.belongsTo(Usuario, { foreignKey: 'usuario_id', as: 'usuario' });
Usuario.hasMany(Compra, { foreignKey: 'usuario_id', as: 'compras' });

// Compra - DetalleCompra (One to Many)
Compra.hasMany(DetalleCompra, { foreignKey: 'compra_id', as: 'detalles' });
DetalleCompra.belongsTo(Compra, { foreignKey: 'compra_id', as: 'compra' });

// Producto - DetalleCompra (One to Many)
Producto.hasMany(DetalleCompra, { foreignKey: 'producto_id', as: 'detalles_compras' });
DetalleCompra.belongsTo(Producto, { foreignKey: 'producto_id', as: 'producto' });

// Producto - Resena (One to Many)
Producto.hasMany(Resena, { foreignKey: 'producto_id', as: 'resenas' });
Resena.belongsTo(Producto, { foreignKey: 'producto_id', as: 'producto' });

// Usuario - Resena (One to Many)
Usuario.hasMany(Resena, { foreignKey: 'usuario_id', as: 'resenas' });
Resena.belongsTo(Usuario, { foreignKey: 'usuario_id', as: 'usuario' });

module.exports = {
  sequelize,
  Rol,
  Usuario,
  Categoria,
  Producto,
  Compra,
  DetalleCompra,
  Resena
};
