const { sequelize, Rol, Usuario, Categoria, Producto } = require('../models');
const bcrypt = require('bcryptjs');

const seedDatabase = async () => {
  try {
    console.log('🌱 Iniciando seed de base de datos...');

    // Sincronizar modelos (crear tablas)
    await sequelize.sync({ force: true }); // force: true borra y recrea las tablas
    console.log('✅ Tablas creadas exitosamente');

    // 1. Crear roles
    const roles = await Rol.bulkCreate([
      { nombre: 'admin', descripcion: 'Administrador del sistema' },
      { nombre: 'cliente', descripcion: 'Cliente regular' }
    ]);
    console.log('✅ Roles creados:', roles.length);

    const rolAdmin = roles.find(r => r.nombre === 'admin');
    const rolCliente = roles.find(r => r.nombre === 'cliente');

    // 2. Crear usuario admin
    const admin = await Usuario.create({
      nombre: 'Admin',
      apellidos: 'Principal',
      correo: 'admin@gmail.com',
      password: 'admin123', // Se hasheará automáticamente por el hook
      telefono: '+56912345678',
      direccion: 'Oficina Central',
      puntos_fidelidad: 0,
      rol_id: rolAdmin.id
    });
    console.log('✅ Usuario admin creado');

    // 3. Crear usuario cliente de prueba
    const cliente = await Usuario.create({
      nombre: 'Juan',
      apellidos: 'Pérez',
      correo: 'juan@duocuc.cl',
      password: 'cliente123',
      telefono: '+56987654321',
      direccion: 'Av. Siempre Viva 123, Santiago',
      puntos_fidelidad: 500,
      rol_id: rolCliente.id
    });
    console.log('✅ Usuario cliente creado');

    // 4. Crear categorías
    const categorias = await Categoria.bulkCreate([
      { nombre: 'Consolas', descripcion: 'Consolas de videojuegos de última generación' },
      { nombre: 'Videojuegos', descripcion: 'Juegos para todas las plataformas' },
      { nombre: 'Accesorios', descripcion: 'Periféricos y accesorios gaming' },
      { nombre: 'PC Gaming', descripcion: 'Componentes y equipos para PC gamer' },
      { nombre: 'Merchandising', descripcion: 'Figuras, posters y coleccionables' }
    ]);
    console.log('✅ Categorías creadas:', categorias.length);

    // 5. Crear productos de ejemplo
    const productos = await Producto.bulkCreate([
      // Consolas
      {
        nombre: 'PlayStation 5',
        descripcion: 'Consola de última generación con tecnología de trazado de rayos',
        precio: 499990,
        stock: 15,
        img: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=500',
        categoria_id: categorias[0].id,
        destacado: true
      },
      {
        nombre: 'Xbox Series X',
        descripcion: 'La consola Xbox más potente jamás creada',
        precio: 479990,
        stock: 12,
        img: 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=500',
        categoria_id: categorias[0].id,
        destacado: true
      },
      {
        nombre: 'Nintendo Switch OLED',
        descripcion: 'Consola híbrida con pantalla OLED de 7 pulgadas',
        precio: 349990,
        stock: 20,
        img: 'https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?w=500',
        categoria_id: categorias[0].id,
        destacado: false
      },
      // Videojuegos
      {
        nombre: 'The Last of Us Part II',
        descripcion: 'Aventura post-apocalíptica exclusiva de PlayStation',
        precio: 39990,
        stock: 30,
        img: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=500',
        categoria_id: categorias[1].id,
        destacado: true
      },
      {
        nombre: 'Elden Ring',
        descripcion: 'RPG de acción del creador de Dark Souls',
        precio: 49990,
        stock: 25,
        img: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=500',
        categoria_id: categorias[1].id,
        destacado: true
      },
      {
        nombre: 'FIFA 24',
        descripcion: 'El simulador de fútbol más realista',
        precio: 59990,
        stock: 40,
        img: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=500',
        categoria_id: categorias[1].id,
        destacado: false
      },
      // Accesorios
      {
        nombre: 'DualSense Controller',
        descripcion: 'Control inalámbrico para PlayStation 5',
        precio: 69990,
        stock: 50,
        img: 'https://images.unsplash.com/photo-1592840496694-26d035b52b48?w=500',
        categoria_id: categorias[2].id,
        destacado: false
      },
      {
        nombre: 'Headset Gamer RGB',
        descripcion: 'Auriculares gaming con sonido 7.1 surround',
        precio: 79990,
        stock: 35,
        img: 'https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=500',
        categoria_id: categorias[2].id,
        destacado: true
      },
      {
        nombre: 'Teclado Mecánico RGB',
        descripcion: 'Teclado mecánico gaming con switches Cherry MX',
        precio: 129990,
        stock: 18,
        img: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=500',
        categoria_id: categorias[2].id,
        destacado: false
      },
      // PC Gaming
      {
        nombre: 'RTX 4070 Ti',
        descripcion: 'Tarjeta gráfica NVIDIA de alto rendimiento',
        precio: 899990,
        stock: 8,
        img: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=500',
        categoria_id: categorias[3].id,
        destacado: true
      },
      {
        nombre: 'Ryzen 9 7950X',
        descripcion: 'Procesador AMD de 16 núcleos',
        precio: 699990,
        stock: 10,
        img: 'https://images.unsplash.com/photo-1555617981-dac3880eac6e?w=500',
        categoria_id: categorias[3].id,
        destacado: false
      },
      // Merchandising
      {
        nombre: 'Figura Kratos God of War',
        descripcion: 'Figura coleccionable de 30cm de altura',
        precio: 89990,
        stock: 15,
        img: 'https://images.unsplash.com/photo-1601814933824-fd0b574dd592?w=500',
        categoria_id: categorias[4].id,
        destacado: false
      }
    ]);
    console.log('✅ Productos creados:', productos.length);

    console.log('\n✨ Seed completado exitosamente!');
    console.log('\n📋 Datos de prueba:');
    console.log('   Admin: admin@gmail.com / admin123');
    console.log('   Cliente: juan@duocuc.cl / cliente123');
    console.log(`   Categorías: ${categorias.length}`);
    console.log(`   Productos: ${productos.length}`);

  } catch (error) {
    console.error('❌ Error en el seed:', error);
    throw error;
  }
};

// Ejecutar seed si se llama directamente
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log('\n🎉 Base de datos inicializada correctamente');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Error fatal:', error);
      process.exit(1);
    });
}

module.exports = seedDatabase;
