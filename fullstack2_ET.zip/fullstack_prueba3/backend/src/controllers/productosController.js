const { Producto, Categoria, Resena, Usuario } = require('../models');

// @desc    Obtener todos los productos
// @route   GET /api/productos
// @access  Public
const obtenerProductos = async (req, res, next) => {
  try {
    const { categoria_id, destacado } = req.query;

    const where = {};
    if (categoria_id) where.categoria_id = categoria_id;
    if (destacado !== undefined) where.destacado = destacado === 'true';

    const productos = await Producto.findAll({
      where,
      include: [
        { model: Categoria, as: 'categoria' },
        {
          model: Resena,
          as: 'resenas',
          include: [{ model: Usuario, as: 'usuario', attributes: ['nombre', 'apellidos'] }]
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json({
      success: true,
      count: productos.length,
      data: productos
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Obtener un producto por ID
// @route   GET /api/productos/:id
// @access  Public
const obtenerProducto = async (req, res, next) => {
  try {
    const producto = await Producto.findByPk(req.params.id, {
      include: [
        { model: Categoria, as: 'categoria' },
        {
          model: Resena,
          as: 'resenas',
          include: [{ model: Usuario, as: 'usuario', attributes: ['nombre', 'apellidos'] }]
        }
      ]
    });

    if (!producto) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }

    res.json({
      success: true,
      data: producto
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Crear producto
// @route   POST /api/productos
// @access  Private/Admin
const crearProducto = async (req, res, next) => {
  try {
    const { nombre, descripcion, precio, stock, img, categoria_id, destacado } = req.body;

    // Validaciones
    if (!nombre || !precio || !categoria_id) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona nombre, precio y categoría'
      });
    }

    const producto = await Producto.create({
      nombre,
      descripcion,
      precio,
      stock: stock || 0,
      img,
      categoria_id,
      destacado: destacado || false
    });

    const productoCreado = await Producto.findByPk(producto.id, {
      include: [{ model: Categoria, as: 'categoria' }]
    });

    res.status(201).json({
      success: true,
      message: 'Producto creado exitosamente',
      data: productoCreado
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Actualizar producto
// @route   PUT /api/productos/:id
// @access  Private/Admin
const actualizarProducto = async (req, res, next) => {
  try {
    const producto = await Producto.findByPk(req.params.id);

    if (!producto) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }

    const { nombre, descripcion, precio, stock, img, categoria_id, destacado } = req.body;

    // Actualizar campos
    if (nombre) producto.nombre = nombre;
    if (descripcion !== undefined) producto.descripcion = descripcion;
    if (precio) producto.precio = precio;
    if (stock !== undefined) producto.stock = stock;
    if (img !== undefined) producto.img = img;
    if (categoria_id) producto.categoria_id = categoria_id;
    if (destacado !== undefined) producto.destacado = destacado;

    await producto.save();

    const productoActualizado = await Producto.findByPk(producto.id, {
      include: [{ model: Categoria, as: 'categoria' }]
    });

    res.json({
      success: true,
      message: 'Producto actualizado exitosamente',
      data: productoActualizado
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Eliminar producto
// @route   DELETE /api/productos/:id
// @access  Private/Admin
const eliminarProducto = async (req, res, next) => {
  try {
    const producto = await Producto.findByPk(req.params.id);

    if (!producto) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }

    await producto.destroy();

    res.json({
      success: true,
      message: 'Producto eliminado exitosamente',
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  obtenerProductos,
  obtenerProducto,
  crearProducto,
  actualizarProducto,
  eliminarProducto
};
