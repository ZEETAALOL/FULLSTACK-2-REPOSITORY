const jwt = require('jsonwebtoken');
const { Usuario, Rol } = require('../models');

// Función helper para generar JWT
const generarToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d'
  });
};

// @desc    Registrar nuevo usuario
// @route   POST /api/auth/register
// @access  Public
const registrar = async (req, res, next) => {
  try {
    const { nombre, apellidos, correo, password, telefono, direccion } = req.body;

    // Validaciones básicas
    if (!nombre || !apellidos || !correo || !password) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona todos los campos requeridos'
      });
    }

    // Verificar si el usuario ya existe
    const usuarioExiste = await Usuario.findOne({ where: { correo } });
    if (usuarioExiste) {
      return res.status(400).json({
        success: false,
        message: 'El correo ya está registrado'
      });
    }

    // Obtener rol de cliente (por defecto)
    const rolCliente = await Rol.findOne({ where: { nombre: 'cliente' } });
    if (!rolCliente) {
      return res.status(500).json({
        success: false,
        message: 'Error al crear usuario: rol no encontrado'
      });
    }

    // Crear usuario
    const usuario = await Usuario.create({
      nombre,
      apellidos,
      correo,
      password,
      telefono,
      direccion,
      rol_id: rolCliente.id
    });

    // Obtener usuario con rol para la respuesta
    const usuarioConRol = await Usuario.findByPk(usuario.id, {
      attributes: { exclude: ['password'] },
      include: [{ model: Rol, as: 'rol' }]
    });

    // Generar token
    const token = generarToken(usuario.id);

    res.status(201).json({
      success: true,
      message: 'Usuario registrado exitosamente',
      data: {
        usuario: usuarioConRol,
        token
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Login de usuario
// @route   POST /api/auth/login
// @access  Public
const login = async (req, res, next) => {
  try {
    const { correo, password } = req.body;

    // Validar campos
    if (!correo || !password) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona correo y contraseña'
      });
    }

    // Buscar usuario con rol
    const usuario = await Usuario.findOne({
      where: { correo },
      include: [{ model: Rol, as: 'rol' }]
    });

    if (!usuario) {
      return res.status(401).json({
        success: false,
        message: 'Credenciales inválidas'
      });
    }

    // Verificar password
    const passwordValido = await usuario.compararPassword(password);
    if (!passwordValido) {
      return res.status(401).json({
        success: false,
        message: 'Credenciales inválidas'
      });
    }

    // Generar token
    const token = generarToken(usuario.id);

    // Remover password de la respuesta
    const usuarioSinPassword = usuario.toJSON();
    delete usuarioSinPassword.password;

    res.json({
      success: true,
      message: 'Login exitoso',
      data: {
        usuario: usuarioSinPassword,
        token
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Obtener usuario autenticado
// @route   GET /api/auth/me
// @access  Private
const obtenerPerfil = async (req, res, next) => {
  try {
    const usuario = await Usuario.findByPk(req.user.id, {
      attributes: { exclude: ['password'] },
      include: [{ model: Rol, as: 'rol' }]
    });

    res.json({
      success: true,
      data: usuario
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  registrar,
  login,
  obtenerPerfil
};
