const { Compra, DetalleCompra, Producto, Usuario, Rol } = require('../models');
const { sequelize } = require('../config/database');

// @desc    Crear una nueva compra
// @route   POST /api/compras
// @access  Private
const crearCompra = async (req, res, next) => {
  const t = await sequelize.transaction();

  try {
    const {
      productos,
      total,
      descuento_duoc,
      descuento_puntos,
      direccion_envio
    } = req.body;

    // Validaciones
    if (!productos || productos.length === 0) {
      await t.rollback();
      return res.status(400).json({
        success: false,
        message: 'Debes incluir al menos un producto en la compra'
      });
    }

    if (!direccion_envio) {
      await t.rollback();
      return res.status(400).json({
        success: false,
        message: 'Debes proporcionar una dirección de envío'
      });
    }

    // Crear la compra
    const compra = await Compra.create({
      usuario_id: req.user.id,
      total,
      descuento_duoc: descuento_duoc || 0,
      descuento_puntos: descuento_puntos || 0,
      direccion_envio,
      estado: 'completada'
    }, { transaction: t });

    // Crear los detalles de compra y actualizar stock
    for (const item of productos) {
      const producto = await Producto.findByPk(item.producto_id, { transaction: t });

      if (!producto) {
        await t.rollback();
        return res.status(404).json({
          success: false,
          message: `Producto con ID ${item.producto_id} no encontrado`
        });
      }

      // Verificar stock
      if (producto.stock < item.cantidad) {
        await t.rollback();
        return res.status(400).json({
          success: false,
          message: `Stock insuficiente para ${producto.nombre}`
        });
      }

      // Crear detalle de compra
      await DetalleCompra.create({
        compra_id: compra.id,
        producto_id: item.producto_id,
        cantidad: item.cantidad,
        precio_unitario: item.precio_unitario,
        subtotal: item.cantidad * item.precio_unitario
      }, { transaction: t });

      // Actualizar stock
      producto.stock -= item.cantidad;
      await producto.save({ transaction: t });
    }

    // Actualizar puntos de fidelidad del usuario (1 punto por cada $1000)
    const puntosGanados = Math.floor(total / 1000);
    const usuario = await Usuario.findByPk(req.user.id, { transaction: t });
    usuario.puntos_fidelidad += puntosGanados;
    await usuario.save({ transaction: t });

    await t.commit();

    // Obtener la compra completa para la respuesta
    const compraCompleta = await Compra.findByPk(compra.id, {
      include: [
        {
          model: DetalleCompra,
          as: 'detalles',
          include: [{ model: Producto, as: 'producto' }]
        }
      ]
    });

    res.status(201).json({
      success: true,
      message: 'Compra realizada exitosamente',
      data: {
        compra: compraCompleta,
        puntos_ganados: puntosGanados
      }
    });
  } catch (error) {
    await t.rollback();
    next(error);
  }
};

// @desc    Obtener mis compras
// @route   GET /api/compras/mis-compras
// @access  Private
const obtenerMisCompras = async (req, res, next) => {
  try {
    const compras = await Compra.findAll({
      where: { usuario_id: req.user.id },
      include: [
        {
          model: DetalleCompra,
          as: 'detalles',
          include: [{ model: Producto, as: 'producto' }]
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json({
      success: true,
      count: compras.length,
      data: compras
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Obtener todas las compras (Admin)
// @route   GET /api/compras
// @access  Private/Admin
const obtenerTodasCompras = async (req, res, next) => {
  try {
    const compras = await Compra.findAll({
      include: [
        {
          model: Usuario,
          as: 'usuario',
          attributes: { exclude: ['password'] },
          include: [{ model: Rol, as: 'rol' }]
        },
        {
          model: DetalleCompra,
          as: 'detalles',
          include: [{ model: Producto, as: 'producto' }]
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json({
      success: true,
      count: compras.length,
      data: compras
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Obtener una compra por ID
// @route   GET /api/compras/:id
// @access  Private
const obtenerCompra = async (req, res, next) => {
  try {
    const compra = await Compra.findByPk(req.params.id, {
      include: [
        {
          model: Usuario,
          as: 'usuario',
          attributes: { exclude: ['password'] }
        },
        {
          model: DetalleCompra,
          as: 'detalles',
          include: [{ model: Producto, as: 'producto' }]
        }
      ]
    });

    if (!compra) {
      return res.status(404).json({
        success: false,
        message: 'Compra no encontrada'
      });
    }

    // Verificar que la compra pertenezca al usuario (a menos que sea admin)
    if (compra.usuario_id !== req.user.id && req.user.rol.nombre !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para ver esta compra'
      });
    }

    res.json({
      success: true,
      data: compra
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  crearCompra,
  obtenerMisCompras,
  obtenerTodasCompras,
  obtenerCompra
};
