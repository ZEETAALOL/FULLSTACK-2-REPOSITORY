const { Categoria, Producto } = require('../models');

// @desc    Obtener todas las categorías
// @route   GET /api/categorias
// @access  Public
const obtenerCategorias = async (req, res, next) => {
  try {
    const categorias = await Categoria.findAll({
      include: [{ model: Producto, as: 'productos' }],
      order: [['nombre', 'ASC']]
    });

    res.json({
      success: true,
      count: categorias.length,
      data: categorias
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Obtener una categoría por ID
// @route   GET /api/categorias/:id
// @access  Public
const obtenerCategoria = async (req, res, next) => {
  try {
    const categoria = await Categoria.findByPk(req.params.id, {
      include: [{ model: Producto, as: 'productos' }]
    });

    if (!categoria) {
      return res.status(404).json({
        success: false,
        message: 'Categoría no encontrada'
      });
    }

    res.json({
      success: true,
      data: categoria
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Crear categoría
// @route   POST /api/categorias
// @access  Private/Admin
const crearCategoria = async (req, res, next) => {
  try {
    const { nombre, descripcion } = req.body;

    if (!nombre) {
      return res.status(400).json({
        success: false,
        message: 'Por favor proporciona un nombre para la categoría'
      });
    }

    const categoria = await Categoria.create({
      nombre,
      descripcion
    });

    res.status(201).json({
      success: true,
      message: 'Categoría creada exitosamente',
      data: categoria
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Actualizar categoría
// @route   PUT /api/categorias/:id
// @access  Private/Admin
const actualizarCategoria = async (req, res, next) => {
  try {
    const categoria = await Categoria.findByPk(req.params.id);

    if (!categoria) {
      return res.status(404).json({
        success: false,
        message: 'Categoría no encontrada'
      });
    }

    const { nombre, descripcion } = req.body;

    if (nombre) categoria.nombre = nombre;
    if (descripcion !== undefined) categoria.descripcion = descripcion;

    await categoria.save();

    res.json({
      success: true,
      message: 'Categoría actualizada exitosamente',
      data: categoria
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Eliminar categoría
// @route   DELETE /api/categorias/:id
// @access  Private/Admin
const eliminarCategoria = async (req, res, next) => {
  try {
    const categoria = await Categoria.findByPk(req.params.id);

    if (!categoria) {
      return res.status(404).json({
        success: false,
        message: 'Categoría no encontrada'
      });
    }

    // Verificar si tiene productos asociados
    const productos = await Producto.count({ where: { categoria_id: req.params.id } });
    if (productos > 0) {
      return res.status(400).json({
        success: false,
        message: 'No se puede eliminar la categoría porque tiene productos asociados'
      });
    }

    await categoria.destroy();

    res.json({
      success: true,
      message: 'Categoría eliminada exitosamente',
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  obtenerCategorias,
  obtenerCategoria,
  crearCategoria,
  actualizarCategoria,
  eliminarCategoria
};
