const { Usuario, Rol } = require('../models');

// @desc    Obtener todos los usuarios
// @route   GET /api/usuarios
// @access  Private/Admin
const obtenerUsuarios = async (req, res, next) => {
  try {
    const usuarios = await Usuario.findAll({
      attributes: { exclude: ['password'] },
      include: [{ model: Rol, as: 'rol' }],
      order: [['createdAt', 'DESC']]
    });

    res.json({
      success: true,
      count: usuarios.length,
      data: usuarios
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Obtener un usuario por ID
// @route   GET /api/usuarios/:id
// @access  Private/Admin
const obtenerUsuario = async (req, res, next) => {
  try {
    const usuario = await Usuario.findByPk(req.params.id, {
      attributes: { exclude: ['password'] },
      include: [{ model: Rol, as: 'rol' }]
    });

    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    res.json({
      success: true,
      data: usuario
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Actualizar usuario
// @route   PUT /api/usuarios/:id
// @access  Private/Admin
const actualizarUsuario = async (req, res, next) => {
  try {
    const usuario = await Usuario.findByPk(req.params.id);

    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Proteger al admin principal
    if (usuario.correo === 'admin@gmail.com') {
      return res.status(403).json({
        success: false,
        message: 'No se puede modificar el usuario administrador principal'
      });
    }

    const { nombre, apellidos, correo, telefono, direccion, puntos_fidelidad, rol_id } = req.body;

    // Actualizar campos
    if (nombre) usuario.nombre = nombre;
    if (apellidos) usuario.apellidos = apellidos;
    if (correo) usuario.correo = correo;
    if (telefono !== undefined) usuario.telefono = telefono;
    if (direccion !== undefined) usuario.direccion = direccion;
    if (puntos_fidelidad !== undefined) usuario.puntos_fidelidad = puntos_fidelidad;
    if (rol_id) usuario.rol_id = rol_id;

    await usuario.save();

    const usuarioActualizado = await Usuario.findByPk(usuario.id, {
      attributes: { exclude: ['password'] },
      include: [{ model: Rol, as: 'rol' }]
    });

    res.json({
      success: true,
      message: 'Usuario actualizado exitosamente',
      data: usuarioActualizado
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Eliminar usuario
// @route   DELETE /api/usuarios/:id
// @access  Private/Admin
const eliminarUsuario = async (req, res, next) => {
  try {
    const usuario = await Usuario.findByPk(req.params.id);

    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Proteger al admin principal
    if (usuario.correo === 'admin@gmail.com') {
      return res.status(403).json({
        success: false,
        message: 'No se puede eliminar el usuario administrador principal'
      });
    }

    await usuario.destroy();

    res.json({
      success: true,
      message: 'Usuario eliminado exitosamente',
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  obtenerUsuarios,
  obtenerUsuario,
  actualizarUsuario,
  eliminarUsuario
};
