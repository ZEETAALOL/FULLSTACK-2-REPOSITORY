import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCarousel from '../components/ProductCarousel';
import { useProducts } from '../hooks/useLocalStorage';
import { useCart } from '../hooks/useCart';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function Home() {
  const [products] = useProducts();

  const categories = [
    { name: 'Consolas', icon: '🎮', hash: 'Consolas' },
    { name: 'Accesorios', icon: '🖱️', hash: 'Accesorios' },
    { name: 'Juegos de Mesa', icon: '🎲', hash: 'Juegos de Mesa' },
    { name: 'Sillas Gamers', icon: '🪑', hash: 'Sillas Gamers' },
    { name: 'PC Gamer', icon: '🖥️', hash: 'PC Gamer' },
    { name: 'Ropa Gamer', icon: '👕', hash: 'Ropa Gamer' },
  ];

  return (
    <>
      <Header />
      
      {/* Carrusel de productos destacados - Reemplaza banner y productos destacados */}
      <ProductCarousel products={products} />

      <section className="categories section">
        <h2 className="section-title">🎯 Explora por Categorías</h2>
        <div className="grid cats">
          {categories.map((cat, index) => (
            <Link 
              key={cat.hash} 
              className="cat-card" 
              to={`/productos#${cat.hash}`}
              style={{ '--delay': index }}
            >
              <span style={{ fontSize: '2em', display: 'block', marginBottom: '10px' }}>{cat.icon}</span>
              <span>{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Nueva sección de beneficios */}
      <section className="section" style={{ background: 'rgba(189, 46, 255, 0.05)' }}>
        <h2 className="section-title">✨ ¿Por qué elegir Level-Up Gamer?</h2>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '30px', maxWidth: '1200px', margin: '0 auto' }}>
          {[
            { icon: '🚚', title: 'Envío Rápido', desc: 'Despacho a todo Chile en 24-48 horas' },
            { icon: '💳', title: 'Pago Seguro', desc: 'Múltiples métodos de pago protegidos' },
            { icon: '🎓', title: 'Descuento Estudiante', desc: '20% OFF con correo @duocuc.cl' },
            { icon: '🛡️', title: 'Garantía', desc: 'Garantía oficial en todos los productos' }
          ].map((benefit, index) => (
            <div key={index} className="card" style={{ '--delay': index }}>
              <div style={{ fontSize: '3em', marginBottom: '15px' }}>{benefit.icon}</div>
              <h3>{benefit.title}</h3>
              <p style={{ color: 'rgba(255,255,255,0.7)' }}>{benefit.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}

export default Home;
