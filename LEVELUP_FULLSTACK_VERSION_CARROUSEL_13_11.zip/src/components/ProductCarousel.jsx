import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function ProductCarousel({ products }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const { addToCart } = useCart();

  // Filtrar productos destacados (uno de cada categoría)
  const featuredProducts = [
    products.find(p => p.categoria === 'Consolas'),
    products.find(p => p.categoria === 'PC Gamer'),
    products.find(p => p.categoria === 'Sillas Gamers'),
    products.find(p => p.categoria === 'Accesorios'),
    products.find(p => p.categoria === 'Juegos de Mesa'),
  ].filter(Boolean);

  // Auto-play del carrusel
  useEffect(() => {
    if (!isAutoPlaying || featuredProducts.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredProducts.length);
    }, 5000); // Cambia cada 5 segundos

    return () => clearInterval(interval);
  }, [isAutoPlaying, featuredProducts.length]);

  const goToSlide = (index) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Reactiva auto-play después de 10s
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % featuredProducts.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + featuredProducts.length) % featuredProducts.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const handleAddToCart = (product) => {
    addToCart(product);
    alert('✅ Producto añadido al carrito');
  };

  if (featuredProducts.length === 0) {
    return <div>No hay productos destacados disponibles</div>;
  }

  const currentProduct = featuredProducts[currentIndex];

  return (
    <div className="carousel-container">
      <div className="carousel-wrapper">
        {/* Imagen de fondo con overlay */}
        <div 
          className="carousel-background"
          style={{ backgroundImage: `url(${currentProduct.img})` }}
        >
          <div className="carousel-overlay"></div>
        </div>

        {/* Contenido del carrusel */}
        <div className="carousel-content">
          <div className="carousel-info">
            <span className="carousel-badge">⭐ PRODUCTO DESTACADO</span>
            <h1 className="carousel-title">{currentProduct.nombre}</h1>
            <p className="carousel-description">{currentProduct.descripcion}</p>
            
            <div className="carousel-details">
              <div className="carousel-price">
                <span className="price-label">Precio:</span>
                <span className="price-value">{CLP.format(currentProduct.precio)}</span>
              </div>
              <div className="carousel-category">
                <span className="category-label">Categoría:</span>
                <span className="category-value">{currentProduct.categoria}</span>
              </div>
              {currentProduct.stock <= currentProduct.stockCritico && (
                <div className="carousel-stock-alert">
                  ⚠️ ¡Últimas unidades! Solo quedan {currentProduct.stock}
                </div>
              )}
            </div>

            <div className="carousel-actions">
              <Link 
                to={`/producto/${currentProduct.id}`} 
                className="btn-carousel btn-primary"
              >
                🔍 Ver detalles
              </Link>
              <button 
                className="btn-carousel btn-secondary"
                onClick={() => handleAddToCart(currentProduct)}
              >
                🛒 Añadir al carrito
              </button>
            </div>
          </div>

          {/* Imagen del producto */}
          <div className="carousel-image">
            <Link to={`/producto/${currentProduct.id}`}>
              <img 
                src={currentProduct.img} 
                alt={currentProduct.nombre}
                loading="eager"
              />
            </Link>
          </div>
        </div>

        {/* Controles de navegación */}
        <button className="carousel-control prev" onClick={prevSlide} aria-label="Anterior">
          ‹
        </button>
        <button className="carousel-control next" onClick={nextSlide} aria-label="Siguiente">
          ›
        </button>

        {/* Indicadores */}
        <div className="carousel-indicators">
          {featuredProducts.map((_, index) => (
            <button
              key={index}
              className={`indicator ${index === currentIndex ? 'active' : ''}`}
              onClick={() => goToSlide(index)}
              aria-label={`Ir a producto ${index + 1}`}
            />
          ))}
        </div>

        {/* Contador */}
        <div className="carousel-counter">
          {currentIndex + 1} / {featuredProducts.length}
        </div>
      </div>
    </div>
  );
}

export default ProductCarousel;
