import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useUsers, useSession } from '../hooks/useLocalStorage';

function Login() {
  const [users] = useUsers();
  const { login } = useSession();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    correo: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const { correo, password } = formData;
    const user = users.find(u => u.correo === correo && u.pass === password);
    
    if (!user) {
      alert('Credenciales inválidas');
      return;
    }

    login(user);
    alert(`Bienvenido ${user.nombre} (${user.tipo})`);
    
    if (user.tipo === 'Administrador' || user.tipo === 'Vendedor') {
      navigate('/admin');
    } else {
      navigate('/');
    }
  };

  return (
    <>
      <Header />
      
      <main className="section form-section">
        <h1 className="section-title">Iniciar Sesión</h1>
        <form onSubmit={handleSubmit} className="form-card">
          <input 
            type="email" 
            name="correo"
            placeholder="Correo" 
            value={formData.correo}
            onChange={handleChange}
            required 
          />
          <input 
            type="password" 
            name="password"
            placeholder="Contraseña" 
            value={formData.password}
            onChange={handleChange}
            required 
          />
          <button type="submit" className="btn-primary">Ingresar</button>
        </form>
      </main>

      <Footer />
    </>
  );
}

export default Login;
