import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useUsers } from '../hooks/useLocalStorage';
import { validarRUN } from '../utils/validations';

const REGIONES = {
  "Biobío": ["Concepción","Coronel","Talcahuano","Hualpén"],
  "Ñuble": ["Chillán","San Carlos"],
  "RM": ["Santiago","Maipú","Puente Alto"]
};

function Registro() {
  const [users, setUsers] = useUsers();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    run: '',
    nombre: '',
    apellidos: '',
    correo: '',
    password: '',
    region: '',
    comuna: '',
    direccion: ''
  });

  const [comunas, setComunas] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (name === 'region') {
      setComunas(REGIONES[value] || []);
      setFormData(prev => ({ ...prev, comuna: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const run = formData.run.trim().toUpperCase();
    const { nombre, apellidos, correo, password, direccion } = formData;

    // Validaciones
    if (!validarRUN(run)) {
      alert('RUN inválido. Debe ser sin puntos ni guion. Ej: 19011022K');
      return;
    }

    if (!/@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/.test(correo)) {
      alert('Correo no permitido. Solo @duoc.cl, @profesor.duoc.cl o @gmail.com');
      return;
    }

    if (password.length < 4 || password.length > 10) {
      alert('Contraseña debe tener entre 4 y 10 caracteres');
      return;
    }

    if (direccion.length > 300) {
      alert('Dirección excede 300 caracteres');
      return;
    }

    // Verificar si ya existe
    const exists = users.some(u => u.correo === correo || u.run === run);
    if (exists) {
      alert('Usuario ya existe con ese RUN o correo');
      return;
    }

    // Crear nuevo usuario
    const newUser = {
      id: (users[users.length - 1]?.id || 0) + 1,
      run,
      nombre: nombre.trim(),
      apellidos: apellidos.trim(),
      correo: correo.trim(),
      pass: password,
      tipo: 'Cliente',
      direccion: direccion.trim()
    };

    setUsers([...users, newUser]);
    alert('✅ Registro exitoso. Ahora puedes iniciar sesión.');
    navigate('/login');
  };

  return (
    <>
      <Header />
      
      <main className="section form-section">
        <h1 className="section-title">Registro de Usuario</h1>
        <form onSubmit={handleSubmit} className="form-card">
          <input 
            type="text" 
            name="run"
            placeholder="RUN (sin puntos ni guion, ej: 19011022K)" 
            value={formData.run}
            onChange={handleChange}
            required 
          />
          <input 
            type="text" 
            name="nombre"
            placeholder="Nombre" 
            value={formData.nombre}
            onChange={handleChange}
            required 
          />
          <input 
            type="text" 
            name="apellidos"
            placeholder="Apellidos" 
            value={formData.apellidos}
            onChange={handleChange}
            required 
          />
          <input 
            type="email" 
            name="correo"
            placeholder="Correo (@duoc.cl, @profesor.duoc.cl, @gmail.com)" 
            value={formData.correo}
            onChange={handleChange}
            required 
          />
          <input 
            type="password" 
            name="password"
            placeholder="Contraseña (4-10 caracteres)" 
            value={formData.password}
            onChange={handleChange}
            required 
          />
          <select 
            name="region"
            value={formData.region}
            onChange={handleChange}
            required
          >
            <option value="">Selecciona región</option>
            {Object.keys(REGIONES).map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
          <select 
            name="comuna"
            value={formData.comuna}
            onChange={handleChange}
            required
          >
            <option value="">Selecciona comuna</option>
            {comunas.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <input 
            type="text" 
            name="direccion"
            placeholder="Dirección" 
            value={formData.direccion}
            onChange={handleChange}
            required 
          />
          <button type="submit" className="btn-primary">Registrarse</button>
        </form>
      </main>

      <Footer />
    </>
  );
}

export default Registro;
