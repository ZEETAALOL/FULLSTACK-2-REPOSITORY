import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminHeader from '../../components/AdminHeader';
import { useUsers, useSession } from '../../hooks/useLocalStorage';
import { validarRUN } from '../../utils/validations';

function AdminUsuarios() {
  const { session } = useSession();
  const navigate = useNavigate();
  const [users, setUsers] = useUsers();

  const [formData, setFormData] = useState({
    id: '',
    run: '',
    nombre: '',
    apellidos: '',
    correo: '',
    pass: '',
    direccion: '',
    tipo: ''
  });

  useEffect(() => {
    if (!session || session.tipo !== 'Administrador') {
      alert('Acceso restringido. Solo Administradores.');
      navigate('/login');
    }
  }, [session, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const limpiarForm = () => {
    setFormData({
      id: '',
      run: '',
      nombre: '',
      apellidos: '',
      correo: '',
      pass: '',
      direccion: '',
      tipo: ''
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { run, nombre, apellidos, correo, pass, direccion, tipo, id } = formData;
    const runClean = run.trim().toUpperCase();

    // Validaciones
    if (!validarRUN(runClean)) {
      alert('RUN inválido');
      return;
    }

    if (nombre.length === 0 || nombre.length > 50) {
      alert('Nombre (1-50)');
      return;
    }

    if (apellidos.length === 0 || apellidos.length > 100) {
      alert('Apellidos (1-100)');
      return;
    }

    if (!/@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/.test(correo)) {
      alert('Correo no permitido');
      return;
    }

    if (pass.length < 4 || pass.length > 10) {
      alert('Contraseña 4-10 caracteres');
      return;
    }

    if (direccion.length > 300) {
      alert('Dirección máx 300 caracteres');
      return;
    }

    if (!['Administrador', 'Vendedor', 'Cliente'].includes(tipo)) {
      alert('Tipo inválido');
      return;
    }

    const isEdit = Boolean(id);

    if (isEdit) {
      // Editar
      const userId = parseInt(id, 10);
      if (users.some(x => x.id !== userId && (x.correo === correo || x.run === runClean))) {
        alert('RUN o correo ya registrado');
        return;
      }

      const idx = users.findIndex(x => x.id === userId);
      if (idx >= 0) {
        const updated = [...users];
        updated[idx] = {
          ...updated[idx],
          run: runClean,
          nombre: nombre.trim(),
          apellidos: apellidos.trim(),
          correo: correo.trim(),
          pass,
          direccion: direccion.trim(),
          tipo
        };
        setUsers(updated);
      }
    } else {
      // Nuevo
      if (users.some(x => x.correo === correo || x.run === runClean)) {
        alert('RUN o correo ya registrado');
        return;
      }

      const newId = (users[users.length - 1]?.id || 0) + 1;
      setUsers([...users, {
        id: newId,
        run: runClean,
        nombre: nombre.trim(),
        apellidos: apellidos.trim(),
        correo: correo.trim(),
        pass,
        direccion: direccion.trim(),
        tipo
      }]);
    }

    alert('✅ Usuario guardado');
    limpiarForm();
  };

  const handleEditar = (user) => {
    setFormData({
      id: user.id,
      run: user.run,
      nombre: user.nombre,
      apellidos: user.apellidos,
      correo: user.correo,
      pass: user.pass,
      direccion: user.direccion,
      tipo: user.tipo
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEliminar = (id) => {
    if (window.confirm('¿Eliminar usuario?')) {
      setUsers(users.filter(x => x.id !== id));
    }
  };

  if (!session) return null;

  return (
    <div className="admin">
      <AdminHeader />
      <main className="section">
        <form onSubmit={handleSubmit} className="form-card">
          <h2>Nuevo / Editar Usuario</h2>
          <input name="run" placeholder="RUN sin puntos ni guion, ej: 19011022K" value={formData.run} onChange={handleChange} required />
          <input name="nombre" placeholder="Nombre (max 50)" value={formData.nombre} onChange={handleChange} maxLength="50" required />
          <input name="apellidos" placeholder="Apellidos (max 100)" value={formData.apellidos} onChange={handleChange} maxLength="100" required />
          <input name="correo" type="email" placeholder="Correo permitido" value={formData.correo} onChange={handleChange} maxLength="100" required />
          <input name="pass" type="password" placeholder="Contraseña (4-10)" value={formData.pass} onChange={handleChange} required />
          <input name="direccion" placeholder="Dirección (max 300)" value={formData.direccion} onChange={handleChange} maxLength="300" required />
          <select name="tipo" value={formData.tipo} onChange={handleChange} required>
            <option value="">Tipo de Usuario</option>
            <option>Administrador</option>
            <option>Vendedor</option>
            <option>Cliente</option>
          </select>
          <div className="actions">
            <button type="submit" className="btn-primary">Guardar</button>
            <button type="button" className="btn-secondary" onClick={limpiarForm}>Limpiar</button>
          </div>
        </form>

        <h2 className="section-title">Listado de Usuarios</h2>
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>RUN</th>
              <th>Nombre</th>
              <th>Correo</th>
              <th>Tipo</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id}>
                <td>{u.id}</td>
                <td>{u.run}</td>
                <td>{u.nombre} {u.apellidos}</td>
                <td>{u.correo}</td>
                <td>{u.tipo}</td>
                <td>
                  <button onClick={() => handleEditar(u)}>Editar</button>
                  <button onClick={() => handleEliminar(u.id)}>Eliminar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
}

export default AdminUsuarios;
