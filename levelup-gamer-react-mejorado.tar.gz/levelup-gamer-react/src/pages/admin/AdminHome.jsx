import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminHeader from '../../components/AdminHeader';
import { useSession } from '../../hooks/useLocalStorage';

function AdminHome() {
  const { session } = useSession();
  const navigate = useNavigate();

  useEffect(() => {
    if (!session || !['Administrador', 'Vendedor'].includes(session.tipo)) {
      alert('Acceso restringido. Inicia sesión con perfil autorizado.');
      navigate('/login');
    }
  }, [session, navigate]);

  if (!session) return null;

  return (
    <div className="admin">
      <AdminHeader />
      <main className="section">
        <div className="info-card">
          <p>
            Usa el menú para gestionar <b>Productos</b> y <b>Usuarios</b>.
          </p>
          <p>Solo roles: <b>Administrador</b> y <b>Vendedor</b>.</p>
          <p style={{ marginTop: '20px' }}>
            Sesión actual: <strong>{session.nombre}</strong> ({session.tipo})
          </p>
        </div>
      </main>
    </div>
  );
}

export default AdminHome;
