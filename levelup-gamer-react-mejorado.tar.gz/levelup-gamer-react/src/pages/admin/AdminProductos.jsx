import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminHeader from '../../components/AdminHeader';
import { useProducts } from '../../hooks/useLocalStorage';
import { useSession } from '../../hooks/useLocalStorage';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function AdminProductos() {
  const { session } = useSession();
  const navigate = useNavigate();
  const [products, setProducts] = useProducts();

  const [formData, setFormData] = useState({
    id: '',
    codigo: '',
    nombre: '',
    descripcion: '',
    precio: '',
    stock: '',
    stockCritico: '',
    categoria: '',
    img: ''
  });

  useEffect(() => {
    if (!session || !['Administrador', 'Vendedor'].includes(session.tipo)) {
      alert('Acceso restringido. Inicia sesión con perfil autorizado.');
      navigate('/login');
    }
  }, [session, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const limpiarForm = () => {
    setFormData({
      id: '',
      codigo: '',
      nombre: '',
      descripcion: '',
      precio: '',
      stock: '',
      stockCritico: '',
      categoria: '',
      img: ''
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { codigo, nombre, descripcion, precio, stock, stockCritico, categoria, img, id } = formData;

    // Validaciones
    if (codigo.length < 3) {
      alert('Código: mínimo 3 caracteres');
      return;
    }

    if (nombre.length === 0 || nombre.length > 100) {
      alert('Nombre requerido (max 100)');
      return;
    }

    if (descripcion.length > 500) {
      alert('Descripción excede 500 caracteres');
      return;
    }

    const precioNum = parseFloat(precio);
    if (!(precioNum >= 0)) {
      alert('Precio debe ser ≥ 0');
      return;
    }

    const stockNum = parseInt(stock, 10);
    if (!(Number.isInteger(stockNum) && stockNum >= 0)) {
      alert('Stock entero ≥ 0');
      return;
    }

    const stockCriticoNum = stockCritico === '' ? null : parseInt(stockCritico, 10);
    if (stockCriticoNum !== null && !(Number.isInteger(stockCriticoNum) && stockCriticoNum >= 0)) {
      alert('Stock crítico entero ≥ 0');
      return;
    }

    if (!categoria) {
      alert('Selecciona categoría');
      return;
    }

    const isEdit = Boolean(id);
    const existsCodigo = products.some(
      x => x.codigo.toLowerCase() === codigo.toLowerCase() && (!isEdit || x.id !== parseInt(id, 10))
    );
    if (existsCodigo) {
      alert('Código de producto ya existe');
      return;
    }

    if (isEdit) {
      // Editar
      const idx = products.findIndex(x => x.id === parseInt(id, 10));
      if (idx >= 0) {
        const updated = [...products];
        updated[idx] = {
          ...updated[idx],
          codigo,
          nombre,
          descripcion,
          precio: precioNum,
          stock: stockNum,
          stockCritico: stockCriticoNum,
          categoria,
          img
        };
        setProducts(updated);
      }
    } else {
      // Nuevo
      const newId = (products[products.length - 1]?.id || 0) + 1;
      setProducts([...products, {
        id: newId,
        codigo,
        nombre,
        descripcion,
        precio: precioNum,
        stock: stockNum,
        stockCritico: stockCriticoNum,
        categoria,
        img
      }]);
    }

    alert('✅ Producto guardado');
    limpiarForm();
  };

  const handleEditar = (product) => {
    setFormData({
      id: product.id,
      codigo: product.codigo,
      nombre: product.nombre,
      descripcion: product.descripcion || '',
      precio: product.precio,
      stock: product.stock,
      stockCritico: product.stockCritico ?? '',
      categoria: product.categoria,
      img: product.img || ''
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEliminar = (id) => {
    if (window.confirm('¿Eliminar producto?')) {
      setProducts(products.filter(x => x.id !== id));
    }
  };

  if (!session) return null;

  return (
    <div className="admin">
      <AdminHeader />
      <main className="section">
        <form onSubmit={handleSubmit} className="form-card">
          <h2>Nuevo / Editar Producto</h2>
          <input name="codigo" placeholder="Código (min 3)" value={formData.codigo} onChange={handleChange} required />
          <input name="nombre" placeholder="Nombre (max 100)" value={formData.nombre} onChange={handleChange} maxLength="100" required />
          <textarea name="descripcion" placeholder="Descripción (opcional, max 500)" value={formData.descripcion} onChange={handleChange} maxLength="500" />
          <input name="precio" type="number" placeholder="Precio (min 0)" value={formData.precio} onChange={handleChange} min="0" step="0.01" required />
          <input name="stock" type="number" placeholder="Stock (entero, min 0)" value={formData.stock} onChange={handleChange} min="0" step="1" required />
          <input name="stockCritico" type="number" placeholder="Stock crítico (opcional, min 0)" value={formData.stockCritico} onChange={handleChange} min="0" step="1" />
          <select name="categoria" value={formData.categoria} onChange={handleChange} required>
            <option value="">Categoría</option>
            <option>Consolas</option>
            <option>Accesorios</option>
            <option>Juegos de Mesa</option>
            <option>Sillas Gamers</option>
            <option>PC Gamer</option>
            <option>Ropa Gamer</option>
          </select>
          <input name="img" placeholder="URL de imagen (opcional)" value={formData.img} onChange={handleChange} />
          <div className="actions">
            <button type="submit" className="btn-primary">Guardar</button>
            <button type="button" className="btn-secondary" onClick={limpiarForm}>Limpiar</button>
          </div>
        </form>

        <h2 className="section-title">Listado de Productos</h2>
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Código</th>
              <th>Nombre</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Categoría</th>
              <th>Img</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.codigo}</td>
                <td>{p.nombre}</td>
                <td>{CLP.format(p.precio)}</td>
                <td>
                  {p.stock}
                  {p.stockCritico != null && p.stock <= p.stockCritico && ' ⚠️'}
                </td>
                <td>{p.categoria}</td>
                <td>{p.img ? <a href={p.img} target="_blank" rel="noopener noreferrer">Ver</a> : '-'}</td>
                <td>
                  <button onClick={() => handleEditar(p)}>Editar</button>
                  <button onClick={() => handleEliminar(p.id)}>Eliminar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
}

export default AdminProductos;
