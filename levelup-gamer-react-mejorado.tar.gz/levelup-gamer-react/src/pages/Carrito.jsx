import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useCart } from '../hooks/useCart';
import { useSession } from '../hooks/useLocalStorage';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

// Fix para iconos de Leaflet en React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function LocationMarker({ position, setPosition }) {
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
    },
  });

  return position === null ? null : <Marker position={position} />;
}

function Carrito() {
  const { groupedCart, setQuantity, removeFromCart, clearCart } = useCart();
  const { session } = useSession();
  const groups = groupedCart();

  const [shipping, setShipping] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('shippingAddress')) || {};
    } catch {
      return {};
    }
  });

  const [showMap, setShowMap] = useState(false);
  const [markerPosition, setMarkerPosition] = useState(null);

  const duocDiscountRate = () => {
    const mail = session?.correo || '';
    return /@(duoc\.cl|profesor\.duoc\.cl)$/i.test(mail) ? 0.20 : 0;
  };

  const cartTotals = () => {
    const subtotal = groups.reduce((s, g) => s + g.precio * g.qty, 0);
    const rate = duocDiscountRate();
    const discount = Math.round(subtotal * rate);
    const total = subtotal - discount;
    return { subtotal, rate, discount, total };
  };

  const totals = cartTotals();

  const handleShippingChange = (e) => {
    const { name, value } = e.target;
    setShipping(prev => ({ ...prev, [name]: value }));
  };

  const handleUsarPunto = () => {
    if (!markerPosition) {
      alert('Primero haz click en el mapa para colocar el punto.');
      return;
    }
    setShipping(prev => ({
      ...prev,
      lat: markerPosition.lat.toFixed(6),
      lng: markerPosition.lng.toFixed(6)
    }));
    setShowMap(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!shipping.direccion) {
      alert('Indica tu dirección de envío.');
      return;
    }
    if (!(shipping.lat && shipping.lng)) {
      alert('Por favor selecciona el punto exacto en el mapa.');
      return;
    }
    localStorage.setItem('shippingAddress', JSON.stringify(shipping));
    alert('¡Compra confirmada! Gracias por tu pedido 🛒');
    clearCart();
    setShipping({});
  };

  if (groups.length === 0) {
    return (
      <>
        <Header />
        <main className="section">
          <h1 className="section-title">Tu carrito</h1>
          <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
            <p>Tu carrito está vacío.</p>
            <a href="/productos" className="btn-primary" style={{ marginTop: '20px', display: 'inline-block' }}>
              Ir al catálogo
            </a>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">Tu carrito</h1>
        <div className="grid" style={{ gridTemplateColumns: '2fr 1fr', gap: '20px' }}>
          <div className="stack">
            {groups.map(g => (
              <div key={g.id} className="card p" style={{ display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'center', gap: '12px' }}>
                <div>
                  <div><strong>{g.nombre}</strong></div>
                  <div className="muted">ID {g.id}</div>
                  <div>{CLP.format(g.precio)} c/u</div>
                </div>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <label className="muted">Cantidad</label>
                  <input 
                    type="number" 
                    min="0" 
                    value={g.qty} 
                    onChange={(e) => setQuantity(g.id, e.target.value)}
                    style={{ width: '80px', padding: '8px', borderRadius: '6px', border: '1px solid #333', background: '#222', color: '#fff' }} 
                  />
                  <button className="btn-secondary" onClick={() => removeFromCart(g.id)}>Quitar uno</button>
                </div>
              </div>
            ))}
          </div>

          <aside className="card p">
            <h3>Resumen</h3>
            <div className="stack">
              <div className="line"><span>Subtotal</span><strong>{CLP.format(totals.subtotal)}</strong></div>
              <div className="line"><span>Descuento {totals.rate > 0 ? '(DUOC 20%)' : ''}</span><strong>-{CLP.format(totals.discount)}</strong></div>
              <div className="line total"><span>Total</span><strong>{CLP.format(totals.total)}</strong></div>
            </div>
            
            <hr />
            
            <h3>Envío</h3>
            <form onSubmit={handleSubmit} className="stack">
              <input 
                name="nombre" 
                placeholder="Nombre de quien recibe" 
                value={shipping.nombre || ''} 
                onChange={handleShippingChange}
                maxLength="100" 
                required 
              />
              <input 
                name="direccion" 
                placeholder="Dirección (calle y número)" 
                value={shipping.direccion || ''} 
                onChange={handleShippingChange}
                maxLength="300" 
                required 
              />

              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <button className="btn-secondary" type="button" onClick={() => setShowMap(!showMap)}>
                  {showMap ? 'Cerrar mapa' : 'Elegir en el mapa'}
                </button>
                <span className="muted">Click en el mapa para marcar</span>
              </div>

              {showMap && (
                <div className="card p" style={{ marginTop: '10px' }}>
                  <MapContainer 
                    center={[-33.45, -70.6667]} 
                    zoom={12} 
                    style={{ height: '320px', borderRadius: '12px', zIndex: 1 }}
                  >
                    <TileLayer
                      attribution='&copy; OpenStreetMap'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <LocationMarker position={markerPosition} setPosition={setMarkerPosition} />
                  </MapContainer>
                  <div className="muted" style={{ marginTop: '8px' }}>
                    Click en el mapa para marcar. Luego presiona "Usar este punto".
                  </div>
                  <button className="btn-primary" type="button" onClick={handleUsarPunto} style={{ marginTop: '8px' }}>
                    Usar este punto
                  </button>
                </div>
              )}

              <input type="hidden" name="lat" value={shipping.lat || ''} />
              <input type="hidden" name="lng" value={shipping.lng || ''} />

              {shipping.lat && shipping.lng && (
                <div style={{ marginTop: '10px' }}>
                  <table className="table">
                    <caption>Dirección seleccionada</caption>
                    <tbody>
                      <tr><th>Dirección</th><td>{shipping.direccion}</td></tr>
                      <tr><th>Coordenadas</th><td>{shipping.lat}, {shipping.lng}</td></tr>
                    </tbody>
                  </table>

                  <table className="table" style={{ marginTop: '10px' }}>
                    <caption>Información extra (opcional)</caption>
                    <tbody>
                      <tr>
                        <th>Departamento</th>
                        <td><input name="depto" value={shipping.depto || ''} onChange={handleShippingChange} placeholder="Ej: Torre B, 1204" /></td>
                      </tr>
                      <tr>
                        <th>Casa</th>
                        <td><input name="casa" value={shipping.casa || ''} onChange={handleShippingChange} placeholder="Ej: Pasaje Z, N° 45" /></td>
                      </tr>
                      <tr>
                        <th>Quien recibe</th>
                        <td><input name="receptor" value={shipping.receptor || ''} onChange={handleShippingChange} placeholder="Nombre" /></td>
                      </tr>
                      <tr>
                        <th>Comuna</th>
                        <td><input name="comuna" value={shipping.comuna || ''} onChange={handleShippingChange} /></td>
                      </tr>
                      <tr>
                        <th>Región</th>
                        <td><input name="region" value={shipping.region || ''} onChange={handleShippingChange} /></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              <button className="btn-primary" type="submit" style={{ marginTop: '10px' }}>Confirmar y pagar</button>
            </form>
            <p className="muted" style={{ marginTop: '10px' }}>
              * Si iniciaste sesión con correo institucional DUOC, se aplica 20% OFF automáticamente.
            </p>
          </aside>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default Carrito;
