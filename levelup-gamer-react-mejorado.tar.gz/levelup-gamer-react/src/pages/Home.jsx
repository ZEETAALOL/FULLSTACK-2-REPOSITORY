import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useProducts } from '../hooks/useLocalStorage';
import { useCart } from '../hooks/useCart';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function Home() {
  const [products] = useProducts();
  const { addToCart } = useCart();
  
  // Destacados: variedad de categorías
  const destacados = [
    products.find(p => p.categoria === 'Consolas'),
    products.find(p => p.categoria === 'PC Gamer'),
    products.find(p => p.categoria === 'Sillas Gamers'),
  ].filter(Boolean).slice(0, 3);

  const handleAddToCart = (product) => {
    addToCart(product);
    alert('✅ Producto añadido al carrito');
  };

  const categories = [
    { name: 'Consolas', icon: '🎮', hash: 'Consolas' },
    { name: 'Accesorios', icon: '🖱️', hash: 'Accesorios' },
    { name: 'Juegos de Mesa', icon: '🎲', hash: 'Juegos de Mesa' },
    { name: 'Sillas Gamers', icon: '🪑', hash: 'Sillas Gamers' },
    { name: 'PC Gamer', icon: '🖥️', hash: 'PC Gamer' },
    { name: 'Ropa Gamer', icon: '👕', hash: 'Ropa Gamer' },
  ];

  return (
    <>
      <Header />
      
      <section className="banner">
        <img src="https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1920&h=800&fit=crop" alt="Banner Gamer" />
        <div className="banner-text">
          <h1>¡Bienvenido a la tienda #1 para gamers en Chile!</h1>
          <p>Consolas, periféricos, ropa y más — con estilo y velocidad.</p>
          <Link className="btn-primary" to="/productos">🚀 Ver catálogo completo</Link>
        </div>
      </section>

      <section className="categories section">
        <h2 className="section-title">🎯 Explora por Categorías</h2>
        <div className="grid cats">
          {categories.map((cat, index) => (
            <Link 
              key={cat.hash} 
              className="cat-card" 
              to={`/productos#${cat.hash}`}
              style={{ '--delay': index }}
            >
              <span style={{ fontSize: '2em', display: 'block', marginBottom: '10px' }}>{cat.icon}</span>
              <span>{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="section featured">
        <h2 className="section-title">⭐ Productos Destacados</h2>
        <div className="grid cards">
          {destacados.map((p, index) => (
            <div key={p.id} className="card" style={{ '--delay': index }}>
              <img loading="lazy" src={p.img} alt={p.nombre} />
              <h3>{p.nombre}</h3>
              <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.9em', margin: '10px 0' }}>
                {p.descripcion}
              </p>
              <p style={{ fontSize: '1.4em', fontWeight: '700', color: '#00d4ff', margin: '10px 0' }}>
                {CLP.format(p.precio)}
              </p>
              <button className="btn-primary" onClick={() => handleAddToCart(p)}>
                🛒 Añadir al carrito
              </button>
            </div>
          ))}
        </div>
        <div style={{ textAlign: 'center', marginTop: '40px' }}>
          <Link className="btn-primary" to="/productos">
            Ver todos los productos →
          </Link>
        </div>
      </section>

      {/* Nueva sección de beneficios */}
      <section className="section" style={{ background: 'rgba(189, 46, 255, 0.05)' }}>
        <h2 className="section-title">✨ ¿Por qué elegir Level-Up Gamer?</h2>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '30px', maxWidth: '1200px', margin: '0 auto' }}>
          {[
            { icon: '🚚', title: 'Envío Rápido', desc: 'Despacho a todo Chile en 24-48 horas' },
            { icon: '💳', title: 'Pago Seguro', desc: 'Múltiples métodos de pago protegidos' },
            { icon: '🎓', title: 'Descuento Estudiante', desc: '20% OFF con correo @duoc.cl' },
            { icon: '🛡️', title: 'Garantía', desc: 'Garantía oficial en todos los productos' }
          ].map((benefit, index) => (
            <div key={index} className="card" style={{ '--delay': index }}>
              <div style={{ fontSize: '3em', marginBottom: '15px' }}>{benefit.icon}</div>
              <h3>{benefit.title}</h3>
              <p style={{ color: 'rgba(255,255,255,0.7)' }}>{benefit.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}

export default Home;
