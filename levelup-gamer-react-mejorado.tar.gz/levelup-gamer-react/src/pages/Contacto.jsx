import { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

function Contacto() {
  const [formData, setFormData] = useState({
    nombre: '',
    correo: '',
    comentario: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const { nombre, correo, comentario } = formData;

    // Validaciones
    if (nombre.length > 100) {
      alert('Nombre supera 100 caracteres');
      return;
    }

    if (!/@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/.test(correo)) {
      alert('Correo no permitido. Solo @duoc.cl, @profesor.duoc.cl o @gmail.com');
      return;
    }

    if (comentario.length > 500) {
      alert('Comentario supera 500 caracteres');
      return;
    }

    alert('📨 Mensaje enviado correctamente');
    setFormData({ nombre: '', correo: '', comentario: '' });
  };

  return (
    <>
      <Header />
      
      <main className="section form-section">
        <h1 className="section-title">Contacto</h1>
        <form onSubmit={handleSubmit} className="form-card">
          <input 
            type="text" 
            name="nombre"
            placeholder="Nombre (máx 100 caracteres)" 
            value={formData.nombre}
            onChange={handleChange}
            maxLength="100"
            required 
          />
          <input 
            type="email" 
            name="correo"
            placeholder="Correo (@duoc.cl, @profesor.duoc.cl, @gmail.com)" 
            value={formData.correo}
            onChange={handleChange}
            required 
          />
          <textarea 
            name="comentario"
            placeholder="Escribe tu mensaje (máx 500 caracteres)..." 
            value={formData.comentario}
            onChange={handleChange}
            maxLength="500"
            required
          />
          <button type="submit" className="btn-primary">Enviar</button>
        </form>
      </main>

      <Footer />
    </>
  );
}

export default Contacto;
