import Header from '../components/Header';
import Footer from '../components/Footer';

function Blog() {
  const blogs = [
    {
      id: 1,
      titulo: 'Lanzamiento de la PS5 Pro',
      descripcion: 'Sony prepara una nueva versión con mejor rendimiento gráfico...',
      imagen: '/img/blog1.jpg'
    },
    {
      id: 2,
      titulo: 'Tips para armar tu PC Gamer',
      descripcion: 'Recomendaciones para un setup óptimo y accesible...',
      imagen: '/img/blog2.jpg'
    }
  ];

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">Blog Gamer</h1>
        <div className="grid blogs">
          {blogs.map(blog => (
            <article key={blog.id} className="card">
              <img src={blog.imagen} alt={blog.titulo} />
              <h2>{blog.titulo}</h2>
              <p>{blog.descripcion}</p>
            </article>
          ))}
        </div>
      </main>

      <Footer />
    </>
  );
}

export default Blog;
