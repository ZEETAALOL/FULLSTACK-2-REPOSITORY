import Header from '../components/Header';
import Footer from '../components/Footer';

function Nosotros() {
  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">Sobre Nosotros</h1>
        <div className="card" style={{maxWidth: '800px', margin: '0 auto', textAlign: 'left'}}>
          <p style={{marginBottom: '20px'}}>
            Somos <strong>Level-Up Gamer</strong>, una tienda online creada para los amantes del gaming en Chile. 
            Nuestra misión es ofrecer productos de calidad y apoyar la comunidad gamer.
          </p>
        </div>

        <h2 className="section-title" style={{marginTop: '40px'}}>Equipo</h2>
        <div className="grid team">
          <div className="card">
            <img src="/img/avatar1.jpg" alt="Bastian" />
            <h3>Bastian Martinez</h3>
            <p>Desarrollador backend/frontend</p>
          </div>
          <div className="card">
            <img src="/img/avatar2.jpg" alt="Benjamin" />
            <h3>Benjamin Palma</h3>
            <p>Desarrollador backend/frontend</p>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default Nosotros;
