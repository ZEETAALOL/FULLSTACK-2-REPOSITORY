import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

function Header() {
  const { cartCount } = useCart();

  return (
    <header className="site-header">
      <div className="brand">
        <span className="logo"></span>
        <Link className="brand-name" to="/">Level-Up Gamer</Link>
      </div>
      <nav className="main-nav">
        <Link to="/">Home</Link>
        <Link to="/productos">Productos</Link>
        <Link to="/registro">Registro</Link>
        <Link to="/login">Login</Link>
        <Link to="/nosotros">Nosotros</Link>
        <Link to="/blog">Blog</Link>
        <Link to="/contacto">Contacto</Link>
        <Link to="/admin" className="admin-link">Admin</Link>
      </nav>
      <Link to="/carrito" className="cart-badge">
        🛒<span id="cartCount">{cartCount}</span>
      </Link>
    </header>
  );
}

export default Header;
