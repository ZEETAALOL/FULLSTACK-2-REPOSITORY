import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-grid">
        <div>
          <h4>Level-Up Gamer</h4>
          <p>¡Explora, juega y gana con nosotros!</p>
        </div>
        <div>
          <h4>Links</h4>
          <ul className="footer-links">
            <li><Link to="/productos">Catálogo</Link></li>
            <li><Link to="/blog">Blog</Link></li>
            <li><Link to="/contacto">Contacto</Link></li>
          </ul>
        </div>
        <div>
          <h4>Síguenos</h4>
          <p>
            <a href="#">Instagram</a> · <a href="#">Facebook</a> · <a href="#">X</a>
          </p>
        </div>
      </div>
      <p className="copy">© 2025 Level-Up Gamer. Todos los derechos reservados.</p>
    </footer>
  );
}

export default Footer;
