import { Link } from 'react-router-dom';

function AdminHeader() {
  return (
    <header className="admin-header">
      <h1>Panel de Administración</h1>
      <nav>
        <Link to="/">Tienda</Link>
        <Link to="/admin/productos">Productos</Link>
        <Link to="/admin/usuarios">Usuarios</Link>
      </nav>
    </header>
  );
}

export default AdminHeader;
