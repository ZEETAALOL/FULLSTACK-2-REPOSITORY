// Validación de RUN chileno (sin puntos ni guion)
export function validarRUN(run) {
  const clean = (run || '').toUpperCase().replace(/[^0-9K]/g, '');
  if (clean.length < 7 || clean.length > 9) return false;
  
  const cuerpo = clean.slice(0, -1);
  const dv = clean.slice(-1);
  
  let suma = 0;
  let mult = 2;
  
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpo[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  
  const res = 11 - (suma % 11);
  const dig = (res === 11) ? '0' : (res === 10) ? 'K' : String(res);
  
  return dig === dv;
}

// Validación de correos permitidos
export function validarCorreo(correo) {
  return /@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/.test(correo);
}

// Validación de contraseña
export function validarPassword(password) {
  return password.length >= 4 && password.length <= 10;
}
