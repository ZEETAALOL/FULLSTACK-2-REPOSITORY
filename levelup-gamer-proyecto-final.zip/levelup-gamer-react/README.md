
## Estructura del proyecto

```
levelup-gamer-react/
├── public/
│   └── img/                    # Imágenes del proyecto
├── src/
│   ├── components/            # Componentes reutilizables
│   │   ├── Header.jsx
│   │   ├── Footer.jsx
│   │   └── AdminHeader.jsx
│   ├── hooks/                 # Custom hooks
│   │   ├── useCart.js
│   │   └── useLocalStorage.js
│   ├── pages/                 # Páginas principales
│   │   ├── Home.jsx
│   │   ├── Productos.jsx
│   │   ├── Registro.jsx
│   │   ├── Login.jsx
│   │   ├── Nosotros.jsx
│   │   ├── Blog.jsx
│   │   ├── Contacto.jsx
│   │   ├── Carrito.jsx
│   │   └── admin/            # Páginas de administración
│   │       ├── AdminHome.jsx
│   │       ├── AdminProductos.jsx
│   │       └── AdminUsuarios.jsx
│   ├── utils/                # Utilidades
│   │   └── validations.js
│   ├── App.jsx               # Componente principal con rutas
│   ├── main.jsx              # Punto de entrada
│   └── styles.css            # Estilos globales
├── index.html
├── package.json
└── vite.config.js
```

## Usuarios de prueba

### Administrador
- **Correo:** admin@gmail.com
- **Contraseña:** 1234

### Vendedor
- **Correo:** vendedor@gmail.com
- **Contraseña:** 1234

### Cliente
- **Correo:** cliente@gmail.com
- **Contraseña:** 1234

## Tecnologías utilizadas

- **React 18** - Librería UI
- **Vite** - Build tool y dev server
- **React Router DOM** - Enrutamiento
- **Leaflet + React Leaflet** - Mapas interactivos
- **LocalStorage** - Persistencia de datos

## Para las pruebas unitarias

npm run test:coverage