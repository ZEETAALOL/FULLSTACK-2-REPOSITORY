// SCRIPT DE PRUEBA - Ejecutar en Console del navegador (F12)
// Copia TODO este código y pégalo en la consola

console.clear();
console.log('🧪 === INICIANDO PRUEBAS DEL SISTEMA ===\n');

// Test 1: Verificar que localStorage tiene productos
console.log('📋 Test 1: Verificando productos en localStorage...');
const productsData = localStorage.getItem('productosData');
if (productsData) {
  const products = JSON.parse(productsData);
  console.log(`✅ Productos encontrados: ${products.length}`);
  console.log('Primeros 3 productos:', products.slice(0, 3).map(p => ({
    id: p.id,
    nombre: p.nombre,
    stock: p.stock
  })));
} else {
  console.log('❌ No hay productos en localStorage');
  console.log('💡 Solución: Recarga la página para inicializar productos');
}

console.log('\n---\n');

// Test 2: Verificar carrito en localStorage
console.log('📋 Test 2: Verificando carrito...');
const cartData = localStorage.getItem('carrito');
if (cartData) {
  const cart = JSON.parse(cartData);
  console.log(`🛒 Items en carrito: ${cart.length}`);
  if (cart.length > 0) {
    console.log('Items:', cart);
  }
} else {
  console.log('🛒 Carrito vacío (normal)');
}

console.log('\n---\n');

// Test 3: Simular añadir producto al carrito
console.log('📋 Test 3: Simulando añadir producto...');
const testProduct = {
  id: 1,
  codigo: "CO001",
  nombre: "PlayStation 5 - TEST",
  descripcion: "Producto de prueba",
  precio: 549990,
  stock: 8,
  categoria: "Consolas",
  img: "test.jpg"
};

console.log('Producto de prueba:', {
  id: testProduct.id,
  nombre: testProduct.nombre,
  precio: testProduct.precio,
  stock: testProduct.stock
});

// Simular la lógica de addToCart
let canAdd = true;
let message = '';

if (!testProduct.id) {
  canAdd = false;
  message = 'Sin ID';
}
if (!testProduct.nombre) {
  canAdd = false;
  message = 'Sin nombre';
}
if (testProduct.precio === undefined) {
  canAdd = false;
  message = 'Sin precio';
}
if (testProduct.stock <= 0) {
  canAdd = false;
  message = 'Sin stock';
}

if (canAdd) {
  console.log('✅ El producto PUEDE ser añadido al carrito');
  console.log(`   - ID: ${testProduct.id} ✓`);
  console.log(`   - Nombre: ${testProduct.nombre} ✓`);
  console.log(`   - Precio: $${testProduct.precio} ✓`);
  console.log(`   - Stock: ${testProduct.stock} unidades ✓`);
} else {
  console.log(`❌ El producto NO puede ser añadido: ${message}`);
}

console.log('\n---\n');

// Test 4: Verificar que React está cargado
console.log('📋 Test 4: Verificando React...');
const rootElement = document.getElementById('root');
if (rootElement && rootElement.innerHTML.length > 0) {
  console.log('✅ React está cargado y renderizado');
} else {
  console.log('❌ React no está cargado correctamente');
}

console.log('\n---\n');

// Test 5: Verificar carrusel
console.log('📋 Test 5: Verificando carrusel...');
const carousel = document.querySelector('.carousel-container');
if (carousel) {
  console.log('✅ Carrusel encontrado en DOM');
  const addButton = carousel.querySelector('button');
  if (addButton) {
    console.log('✅ Botón "Añadir al carrito" encontrado');
    console.log('   Texto del botón:', addButton.textContent);
  } else {
    console.log('❌ Botón no encontrado en carrusel');
  }
} else {
  console.log('❌ Carrusel no encontrado en DOM');
}

console.log('\n---\n');

// Test 6: Verificar contador del carrito
console.log('📋 Test 6: Verificando contador del carrito...');
const cartCount = document.getElementById('cartCount');
if (cartCount) {
  console.log(`✅ Contador encontrado. Valor actual: ${cartCount.textContent}`);
} else {
  console.log('❌ Contador del carrito no encontrado');
}

console.log('\n---\n');

// Resumen
console.log('🎯 === RESUMEN DE PRUEBAS ===');
console.log('');
console.log('Si TODO está ✅ pero sigue fallando:');
console.log('1. El problema es caché del navegador');
console.log('2. Cierra TODAS las pestañas de localhost');
console.log('3. Detén el servidor (Ctrl+C)');
console.log('4. Borra: rm -rf node_modules package-lock.json');
console.log('5. Reinstala: npm install');
console.log('6. Inicia: npm run dev');
console.log('7. Abre en pestaña NUEVA');
console.log('');
console.log('Si hay algún ❌:');
console.log('- Copia TODA esta salida');
console.log('- Envíamela para diagnosticar el problema exacto');
console.log('');
console.log('🧪 === FIN DE PRUEBAS ===');
