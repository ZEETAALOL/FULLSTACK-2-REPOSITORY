import { useState, useEffect } from 'react';

// Hook para manejar toasts globalmente
let toastListener = null;

export const showToast = (message, type = 'success') => {
  if (toastListener) {
    toastListener(message, type);
  }
};

function Toast() {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    toastListener = (message, type) => {
      const id = Date.now();
      setToasts(prev => [...prev, { id, message, type }]);

      setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== id));
      }, 4000);
    };

    return () => {
      toastListener = null;
    };
  }, []);

  const removeToast = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div style={{
      position: 'fixed',
      top: '20px',
      right: '20px',
      zIndex: 10000,
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      maxWidth: '400px'
    }}>
      {toasts.map(toast => (
        <div
          key={toast.id}
          onClick={() => removeToast(toast.id)}
          style={{
            background: toast.type === 'success' ? 'linear-gradient(135deg, #00d4ff 0%, #5855fe 100%)' :
                        toast.type === 'error' ? 'linear-gradient(135deg, #ff4444 0%, #cc0000 100%)' :
                        toast.type === 'warning' ? 'linear-gradient(135deg, #f39c12 0%, #e67e22 100%)' :
                        'linear-gradient(135deg, #bd2eff 0%, #5855fe 100%)',
            color: '#fff',
            padding: '15px 20px',
            borderRadius: '12px',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
            cursor: 'pointer',
            animation: 'slideIn 0.3s ease',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            fontWeight: '500',
            fontSize: '0.95em'
          }}
        >
          <span style={{ fontSize: '1.5em' }}>
            {toast.type === 'success' ? '✅' :
             toast.type === 'error' ? '❌' :
             toast.type === 'warning' ? '⚠️' : 'ℹ️'}
          </span>
          <span style={{ flex: 1 }}>{toast.message}</span>
          <span style={{ fontSize: '1.2em', opacity: 0.7 }}>×</span>
        </div>
      ))}
      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}

export default Toast;
