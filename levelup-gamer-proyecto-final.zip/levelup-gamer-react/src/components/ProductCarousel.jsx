import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function ProductCarousel({ products = [] }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { addToCart } = useCart();

  // Filtrar productos destacados cuando los productos estén disponibles
  useEffect(() => {
    setIsLoading(true);
    
    if (products && products.length > 0) {
      const featured = [
        products.find(p => p?.categoria === 'Consolas' && p?.id && p?.nombre),
        products.find(p => p?.categoria === 'PC Gamer' && p?.id && p?.nombre),
        products.find(p => p?.categoria === 'Sillas Gamers' && p?.id && p?.nombre),
        products.find(p => p?.categoria === 'Accesorios' && p?.id && p?.nombre),
        products.find(p => p?.categoria === 'Juegos de Mesa' && p?.id && p?.nombre),
      ].filter(p => p && p.id && p.nombre && p.precio !== undefined);
      
      if (featured.length > 0) {
        setFeaturedProducts(featured);
        setIsLoading(false);
      } else {
        console.error('No se encontraron productos destacados válidos');
        setIsLoading(false);
      }
    }
  }, [products]);

  // Auto-play del carrusel
  useEffect(() => {
    if (!isAutoPlaying || featuredProducts.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredProducts.length);
    }, 5000); // Cambia cada 5 segundos

    return () => clearInterval(interval);
  }, [isAutoPlaying, featuredProducts.length]);

  const goToSlide = (index) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Reactiva auto-play después de 10s
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % featuredProducts.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + featuredProducts.length) % featuredProducts.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const handleAddToCart = (product) => {
    if (!product) {
      console.error('handleAddToCart: producto es null/undefined');
      alert('❌ Error: Producto inválido');
      return;
    }
    
    console.log('Añadiendo al carrito:', product);
    const result = addToCart(product);
    console.log('Resultado:', result);
    alert(result.message);
  };

  // Mostrar loading mientras carga
  if (isLoading || featuredProducts.length === 0) {
    return (
      <div className="carousel-container">
        <div className="carousel-wrapper" style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          background: 'var(--bg-secondary)',
          minHeight: '650px'
        }}>
          <div style={{ 
            textAlign: 'center', 
            color: 'white',
            fontSize: '1.2em'
          }}>
            <div style={{ 
              fontSize: '3em', 
              marginBottom: '20px',
              animation: 'pulse 1.5s ease-in-out infinite'
            }}>⏳</div>
            Cargando productos destacados...
          </div>
        </div>
      </div>
    );
  }

  const currentProduct = featuredProducts[currentIndex];

  // Validación adicional por seguridad
  if (!currentProduct || !currentProduct.id) {
    console.error('currentProduct inválido:', currentProduct, 'featuredProducts:', featuredProducts);
    return (
      <div className="carousel-container">
        <div className="carousel-wrapper" style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          background: 'var(--bg-secondary)',
          minHeight: '650px'
        }}>
          <div style={{ 
            textAlign: 'center', 
            color: 'white',
            fontSize: '1.2em'
          }}>
            <div style={{ fontSize: '2em', marginBottom: '20px' }}>⚠️</div>
            No hay productos destacados disponibles
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="carousel-container">
      <div className="carousel-wrapper">
        {/* Imagen de fondo con overlay */}
        <div 
          className="carousel-background"
          style={{ backgroundImage: `url(${currentProduct.img})` }}
        >
          <div className="carousel-overlay"></div>
        </div>

        {/* Contenido del carrusel */}
        <div className="carousel-content">
          <div className="carousel-info">
            <span className="carousel-badge">⭐ PRODUCTO DESTACADO</span>
            <h1 className="carousel-title">{currentProduct.nombre}</h1>
            <p className="carousel-description">{currentProduct.descripcion}</p>
            
            <div className="carousel-details">
              <div className="carousel-price">
                <span className="price-label">Precio:</span>
                <span className="price-value">{CLP.format(currentProduct.precio)}</span>
              </div>
              <div className="carousel-category">
                <span className="category-label">Categoría:</span>
                <span className="category-value">{currentProduct.categoria}</span>
              </div>
              {currentProduct.stock <= currentProduct.stockCritico && (
                <div className="carousel-stock-alert">
                  ⚠️ ¡Últimas unidades! Solo quedan {currentProduct.stock}
                </div>
              )}
            </div>

            <div className="carousel-actions">
              <Link 
                to={`/producto/${currentProduct.id}`} 
                className="btn-carousel btn-primary"
              >
                🔍 Ver detalles
              </Link>
              <button 
                className="btn-carousel btn-secondary"
                onClick={() => handleAddToCart(currentProduct)}
              >
                🛒 Añadir al carrito
              </button>
            </div>
          </div>

          {/* Imagen del producto */}
          <div className="carousel-image">
            <Link to={`/producto/${currentProduct.id}`}>
              <img 
                src={currentProduct.img} 
                alt={currentProduct.nombre}
                loading="eager"
              />
            </Link>
          </div>
        </div>

        {/* Controles de navegación */}
        <button className="carousel-control prev" onClick={prevSlide} aria-label="Anterior">
          ‹
        </button>
        <button className="carousel-control next" onClick={nextSlide} aria-label="Siguiente">
          ›
        </button>

        {/* Indicadores */}
        <div className="carousel-indicators">
          {featuredProducts.map((_, index) => (
            <button
              key={index}
              className={`indicator ${index === currentIndex ? 'active' : ''}`}
              onClick={() => goToSlide(index)}
              aria-label={`Ir a producto ${index + 1}`}
            />
          ))}
        </div>

        {/* Contador */}
        <div className="carousel-counter">
          {currentIndex + 1} / {featuredProducts.length}
        </div>
      </div>
    </div>
  );
}

export default ProductCarousel;
