const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function Boleta({ compra, usuario, onClose }) {
  const handlePrint = () => {
    window.print();
  };

  if (!compra) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.8)',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}
      onClick={onClose}
    >
      <div
        style={{
          background: '#fff',
          color: '#000',
          maxWidth: '600px',
          width: '100%',
          borderRadius: '12px',
          padding: '40px',
          position: 'relative',
          maxHeight: '90vh',
          overflowY: 'auto'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Botones de acción - solo visibles en pantalla */}
        <div className="no-print" style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
          <button
            onClick={handlePrint}
            style={{
              flex: 1,
              padding: '10px 20px',
              background: 'linear-gradient(135deg, #bd2eff 0%, #5855fe 100%)',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            🖨️ Imprimir Boleta
          </button>
          <button
            onClick={onClose}
            style={{
              flex: 1,
              padding: '10px 20px',
              background: '#f0f0f0',
              color: '#333',
              border: 'none',
              borderRadius: '8px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Cerrar
          </button>
        </div>

        {/* Contenido de la boleta */}
        <div id="boleta-content">
          {/* Encabezado */}
          <div style={{ textAlign: 'center', marginBottom: '30px', paddingBottom: '20px', borderBottom: '2px solid #bd2eff' }}>
            <h1 style={{ margin: '0 0 10px 0', color: '#bd2eff', fontSize: '2em' }}>
              LEVEL-UP GAMER
            </h1>
            <p style={{ margin: '5px 0', color: '#666' }}>Boleta de Venta Electrónica</p>
            <p style={{ margin: '5px 0', fontWeight: 'bold' }}>
              N° {compra.id}
            </p>
            <p style={{ margin: '5px 0', fontSize: '0.9em', color: '#666' }}>
              {new Date(compra.fecha).toLocaleString('es-CL', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </p>
          </div>

          {/* Información del cliente */}
          <div style={{ marginBottom: '20px', padding: '15px', background: '#f9f9f9', borderRadius: '8px' }}>
            <h3 style={{ margin: '0 0 10px 0', color: '#bd2eff', fontSize: '1.2em' }}>
              Datos del Cliente
            </h3>
            <p style={{ margin: '5px 0' }}><strong>Nombre:</strong> {usuario.nombre} {usuario.apellidos}</p>
            <p style={{ margin: '5px 0' }}><strong>Correo:</strong> {usuario.correo}</p>
            {compra.direccion && (
              <p style={{ margin: '5px 0' }}><strong>Dirección de envío:</strong> {compra.direccion}</p>
            )}
          </div>

          {/* Productos */}
          <div style={{ marginBottom: '20px' }}>
            <h3 style={{ margin: '0 0 15px 0', color: '#bd2eff', fontSize: '1.2em' }}>
              Detalle de Productos
            </h3>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #ddd' }}>
                  <th style={{ padding: '10px', textAlign: 'left' }}>Producto</th>
                  <th style={{ padding: '10px', textAlign: 'center' }}>Cant.</th>
                  <th style={{ padding: '10px', textAlign: 'right' }}>Precio Unit.</th>
                  <th style={{ padding: '10px', textAlign: 'right' }}>Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {compra.productos.map((prod, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '10px' }}>{prod.nombre}</td>
                    <td style={{ padding: '10px', textAlign: 'center' }}>{prod.cantidad}</td>
                    <td style={{ padding: '10px', textAlign: 'right' }}>{CLP.format(prod.precio)}</td>
                    <td style={{ padding: '10px', textAlign: 'right' }}>
                      {CLP.format(prod.precio * prod.cantidad)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Resumen de pago */}
          <div style={{ marginTop: '30px', padding: '20px', background: '#f9f9f9', borderRadius: '8px' }}>
            <h3 style={{ margin: '0 0 15px 0', color: '#bd2eff', fontSize: '1.2em' }}>
              Resumen de Pago
            </h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', margin: '8px 0' }}>
              <span>Subtotal:</span>
              <span>
                {CLP.format(compra.total + (compra.descuentoDuoc || 0) + (compra.descuentoPuntos || 0))}
              </span>
            </div>
            {compra.descuentoDuoc > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', margin: '8px 0', color: '#f39c12' }}>
                <span>Descuento DUOC (20%):</span>
                <span>-{CLP.format(compra.descuentoDuoc)}</span>
              </div>
            )}
            {compra.descuentoPuntos > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', margin: '8px 0', color: '#00d4ff' }}>
                <span>Descuento por Puntos:</span>
                <span>-{CLP.format(compra.descuentoPuntos)}</span>
              </div>
            )}
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                margin: '15px 0 0 0',
                paddingTop: '15px',
                borderTop: '2px solid #bd2eff',
                fontSize: '1.3em',
                fontWeight: 'bold'
              }}
            >
              <span>TOTAL:</span>
              <span style={{ color: '#bd2eff' }}>{CLP.format(compra.total)}</span>
            </div>
          </div>

          {/* Pie de página */}
          <div style={{ marginTop: '30px', paddingTop: '20px', borderTop: '1px solid #ddd', textAlign: 'center' }}>
            <p style={{ margin: '5px 0', fontSize: '0.9em', color: '#666' }}>
              Gracias por su compra en Level-Up Gamer
            </p>
            <p style={{ margin: '5px 0', fontSize: '0.85em', color: '#999' }}>
              www.levelupgamer.cl | contacto@levelupgamer.cl
            </p>
            <p style={{ margin: '5px 0', fontSize: '0.85em', color: '#999' }}>
              ¡Disfruta tu producto! 🎮
            </p>
          </div>
        </div>
      </div>

      {/* Estilos para impresión */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #boleta-content, #boleta-content * {
            visibility: visible;
          }
          #boleta-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}

export default Boleta;
