import { Link, useNavigate } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';
import { useCart } from '../hooks/useCart';
import { useSession } from '../hooks/useLocalStorage';
import { useLoyaltyPoints } from '../hooks/useLoyaltyPoints';

function Header() {
  const navigate = useNavigate();
  const { cartCount } = useCart();
  const { session, logout } = useSession();
  const { getUserPoints } = useLoyaltyPoints();
  
  const [displayCartCount, setDisplayCartCount] = useState(cartCount);
  const [displayPoints, setDisplayPoints] = useState(session ? getUserPoints(session.id) : 0);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Actualizar contador de carrito en tiempo real
  useEffect(() => {
    setDisplayCartCount(cartCount);
    
    const handleCartUpdate = (event) => {
      setDisplayCartCount(event.detail.count);
    };
    
    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, [cartCount]);

  // Actualizar puntos en tiempo real
  useEffect(() => {
    if (session) {
      setDisplayPoints(getUserPoints(session.id));
    }
    
    const handlePointsUpdate = () => {
      if (session) {
        setDisplayPoints(getUserPoints(session.id));
      }
    };
    
    window.addEventListener('pointsUpdated', handlePointsUpdate);
    return () => window.removeEventListener('pointsUpdated', handlePointsUpdate);
  }, [session, getUserPoints]);

  // Cerrar dropdown al hacer clic fuera
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    if (window.confirm('¿Estás seguro de que deseas cerrar sesión?')) {
      logout();
      setIsDropdownOpen(false);
      // Disparar evento de logout para que otras páginas lo detecten
      window.dispatchEvent(new Event('userLogout'));
      // Navegar al home después de cerrar sesión
      navigate('/');
    }
  };

  return (
    <header className="site-header">
      <div className="brand">
        <img src="/img/logo.png" alt="Logo" style={{ width: '70px', height: '70px', borderRadius: '12px' }} />
        <Link className="brand-name" to="/">Level-Up Gamer</Link>
      </div>
      <nav className="main-nav">
        <Link to="/">Home</Link>
        <Link to="/productos">Productos</Link>
        <Link to="/nosotros">Nosotros</Link>
        <Link to="/blog">Blog</Link>
        <Link to="/contacto">Contacto</Link>
        {session?.tipo === 'Administrador' && (
          <Link to="/admin" className="admin-link">Admin</Link>
        )}
      </nav>
      <div className="user-actions">
        {/* Carrito */}
        <Link to="/carrito" className="header-action-btn">
          <span className="action-icon">🛒</span>
          <span className="action-badge">{displayCartCount}</span>
        </Link>
        
        {/* Puntos - solo si hay sesión */}
        {session && (
          <div className="header-action-btn points-display">
            <span className="action-icon">⭐</span>
            <span className="action-badge">{displayPoints}</span>
          </div>
        )}
        
        {/* Perfil - siempre visible */}
        <div className="profile-dropdown" ref={dropdownRef}>
          <button className="header-action-btn" onClick={toggleDropdown}>
            <span className="action-icon">👤</span>
          </button>
          {isDropdownOpen && (
            <div className="dropdown-content">
              {session ? (
                <>
                  <Link to="/perfil" onClick={() => setIsDropdownOpen(false)}>
                    👤 Ver Perfil
                  </Link>
                  <Link to="/mis-puntos" onClick={() => setIsDropdownOpen(false)}>
                    💎 Mis Puntos
                  </Link>
                  <button onClick={handleLogout} className="dropdown-btn">
                    🚪 Salir
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setIsDropdownOpen(false)}>
                    🔑 Iniciar Sesión
                  </Link>
                  <Link to="/registro" onClick={() => setIsDropdownOpen(false)}>
                    ✨ Registrarse
                  </Link>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export default Header;