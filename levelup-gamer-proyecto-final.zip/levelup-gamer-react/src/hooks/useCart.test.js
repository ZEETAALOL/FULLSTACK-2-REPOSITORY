import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useCart } from './useCart';

describe('useCart', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('debe iniciar con carrito vacío', () => {
    const { result } = renderHook(() => useCart());
    
    expect(result.current.cart).toEqual([]);
    expect(result.current.cartCount).toBe(0);
  });

  it('debe agregar un producto al carrito', () => {
    const { result } = renderHook(() => useCart());
    const producto = {
      id: 1,
      nombre: 'PlayStation 5',
      precio: 549990
    };
    
    act(() => {
      result.current.addToCart(producto);
    });
    
    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cartCount).toBe(1);
  });

  it('debe agregar múltiples unidades del mismo producto', () => {
    const { result } = renderHook(() => useCart());
    const producto = {
      id: 1,
      nombre: 'PlayStation 5',
      precio: 549990
    };
    
    act(() => {
      result.current.addToCart(producto);
      result.current.addToCart(producto);
      result.current.addToCart(producto);
    });
    
    expect(result.current.cartCount).toBe(3);
  });

  it('debe eliminar una unidad del producto', () => {
    const { result } = renderHook(() => useCart());
    const producto = {
      id: 1,
      nombre: 'PlayStation 5',
      precio: 549990
    };
    
    act(() => {
      result.current.addToCart(producto);
      result.current.addToCart(producto);
    });
    
    expect(result.current.cartCount).toBe(2);
    
    act(() => {
      result.current.removeFromCart(1);
    });
    
    expect(result.current.cartCount).toBe(1);
  });

  it('debe limpiar el carrito completamente', () => {
    const { result } = renderHook(() => useCart());
    const producto = {
      id: 1,
      nombre: 'PlayStation 5',
      precio: 549990
    };
    
    act(() => {
      result.current.addToCart(producto);
      result.current.addToCart(producto);
    });
    
    expect(result.current.cartCount).toBe(2);
    
    act(() => {
      result.current.clearCart();
    });
    
    expect(result.current.cart).toEqual([]);
    expect(result.current.cartCount).toBe(0);
  });

  it('debe agrupar productos correctamente', () => {
    const { result } = renderHook(() => useCart());
    const producto1 = { id: 1, nombre: 'PS5', precio: 549990 };
    const producto2 = { id: 2, nombre: 'Xbox', precio: 529990 };
    
    act(() => {
      result.current.addToCart(producto1);
      result.current.addToCart(producto1);
      result.current.addToCart(producto2);
    });
    
    const grouped = result.current.groupedCart();
    
    expect(grouped).toHaveLength(2);
    expect(grouped[0].qty).toBe(2);
    expect(grouped[1].qty).toBe(1);
  });

  it('debe contar correctamente los productos', () => {
    const { result } = renderHook(() => useCart());
    const producto = { id: 1, nombre: 'PS5', precio: 549990 };
    
    act(() => {
      result.current.addToCart(producto);
      result.current.addToCart(producto);
    });
    
    expect(result.current.cartCount).toBe(2);
  });
});