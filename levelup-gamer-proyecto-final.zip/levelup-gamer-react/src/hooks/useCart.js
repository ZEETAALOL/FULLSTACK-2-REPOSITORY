import { useState, useEffect } from 'react';

const LS_CART = 'carrito';

export function useCart() {
  const [cart, setCart] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(LS_CART)) || [];
    } catch {
      return [];
    }
  });

  const [cartCount, setCartCount] = useState(cart.length);

  useEffect(() => {
    localStorage.setItem(LS_CART, JSON.stringify(cart));
    setCartCount(cart.length);
    // Disparar evento personalizado para actualizar header
    window.dispatchEvent(new CustomEvent('cartUpdated', { detail: { count: cart.length } }));
  }, [cart]);

  const addToCart = (product) => {
    console.log('🔍 addToCart llamado con:', product);
    
    // Validación 1: Producto existe y tiene datos básicos
    if (!product) {
      console.error('❌ Error: producto es null o undefined');
      return { success: false, message: '❌ Error: Producto no válido' };
    }
    
    if (!product.id) {
      console.error('❌ Error: producto sin ID:', product);
      return { success: false, message: '❌ Error: Producto sin identificador' };
    }
    
    if (!product.nombre) {
      console.error('❌ Error: producto sin nombre:', product);
      return { success: false, message: '❌ Error: Producto sin nombre' };
    }
    
    if (product.precio === undefined || product.precio === null) {
      console.error('❌ Error: producto sin precio:', product);
      return { success: false, message: '❌ Error: Producto sin precio' };
    }
    
    console.log('✅ Validación básica pasada');
    
    // Validación 2: Stock disponible
    if (product.stock !== undefined) {
      console.log(`📦 Stock del producto: ${product.stock}`);
      
      if (product.stock <= 0) {
        console.warn('⚠️ Producto sin stock');
        return { success: false, message: '❌ Producto sin stock disponible' };
      }
      
      // Contar cuántos de este producto ya están en el carrito
      const currentQty = cart.filter(item => item.id === product.id).length;
      console.log(`🛒 Cantidad actual en carrito: ${currentQty}`);
      
      if (currentQty >= product.stock) {
        console.warn(`⚠️ Stock máximo alcanzado: ${currentQty}/${product.stock}`);
        return { 
          success: false, 
          message: `❌ Stock máximo alcanzado (${product.stock} unidades disponibles)` 
        };
      }
      
      console.log(`✅ Stock disponible: ${product.stock - currentQty} unidades restantes`);
    } else {
      console.warn('⚠️ Producto no tiene información de stock, añadiendo sin validar');
    }
    
    // Añadir al carrito
    console.log('➕ Añadiendo producto al carrito...');
    setCart(prev => {
      const newCart = [...prev, { 
        id: product.id, 
        nombre: product.nombre, 
        precio: product.precio 
      }];
      console.log('✅ Carrito actualizado. Nuevos items:', newCart.length);
      return newCart;
    });
    
    console.log('🎉 Producto añadido exitosamente');
    return { success: true, message: '✅ Producto añadido al carrito' };
  };

  const removeFromCart = (id) => {
    setCart(prev => {
      const idx = prev.findIndex(item => item.id === id);
      if (idx >= 0) {
        const newCart = [...prev];
        newCart.splice(idx, 1);
        return newCart;
      }
      return prev;
    });
  };

  const setQuantity = (id, qty) => {
    const products = JSON.parse(localStorage.getItem('productosData')) || [];
    const product = products.find(p => p.id === id);
    if (!product) return;

    // Validar que la cantidad no exceda el stock
    const requestedQty = Math.max(0, parseInt(qty, 10));
    const finalQty = Math.min(requestedQty, product.stock);

    const newCart = [];
    for (let i = 0; i < finalQty; i++) {
      newCart.push({ id: product.id, nombre: product.nombre, precio: product.precio });
    }
    
    setCart(prev => [
      ...prev.filter(item => item.id !== id),
      ...newCart
    ]);
  };

  const clearCart = () => {
    setCart([]);
  };

  const groupedCart = () => {
    const map = new Map();
    cart.forEach(item => {
      const key = item.id;
      const g = map.get(key) || { id: item.id, nombre: item.nombre, precio: item.precio, qty: 0 };
      g.qty += 1;
      map.set(key, g);
    });
    return Array.from(map.values());
  };

  return {
    cart,
    cartCount,
    addToCart,
    removeFromCart,
    setQuantity,
    clearCart,
    groupedCart
  };
}
