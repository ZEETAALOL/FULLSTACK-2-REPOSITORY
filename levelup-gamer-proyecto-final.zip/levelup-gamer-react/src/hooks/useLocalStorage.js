import { useState, useEffect } from 'react';

// Seed inicial de productos - CATÁLOGO COMPLETO
const SEED_PRODUCTS = [
  // CONSOLAS
  { 
    id: 1, 
    codigo: "CO001", 
    nombre: "PlayStation 5", 
    descripcion: "Consola de nueva generación con gráficos 4K, SSD ultra rápido y Ray Tracing. Incluye control DualSense con retroalimentación háptica.", 
    precio: 549990, 
    stock: 8, 
    stockCritico: 2, 
    categoria: "Consolas", 
    img: "https://bestmart.cl/cdn/shop/files/consola-sony-ps5-slim-edicion-disco-5899311.png?v=1760166949" 
  },
  { 
    id: 2, 
    codigo: "CO002", 
    nombre: "Xbox Series X", 
    descripcion: "La consola Xbox más potente. 4K a 120fps, compatibilidad con Xbox Game Pass y carga ultra rápida.", 
    precio: 529990, 
    stock: 6, 
    stockCritico: 2, 
    categoria: "Consolas", 
    img: "https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=500&h=500&fit=crop" 
  },
  { 
    id: 3, 
    codigo: "CO003", 
    nombre: "Nintendo Switch OLED", 
    descripcion: "Consola híbrida con pantalla OLED de 7 pulgadas, 64GB de almacenamiento y dock mejorado.", 
    precio: 349990, 
    stock: 12, 
    stockCritico: 3, 
    categoria: "Consolas", 
    img: "https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?w=500&h=500&fit=crop" 
  },
  { 
    id: 4, 
    codigo: "CO004", 
    nombre: "Steam Deck", 
    descripcion: "PC portátil para gaming con pantalla de 7 pulgadas, AMD APU y acceso a toda tu biblioteca de Steam.", 
    precio: 449990, 
    stock: 5, 
    stockCritico: 2, 
    categoria: "Consolas", 
    img: "https://www.stuff.tv/wp-content/uploads/sites/2/2023/11/Steam-Deck-OLED-lead.jpg?w=1080" 
  },

  // ACCESORIOS
  { 
    id: 5, 
    codigo: "AC001", 
    nombre: "Control Xbox Wireless Elite Series 2", 
    descripcion: "Control pro con palancas intercambiables, gatillos ajustables y hasta 40 horas de batería.", 
    precio: 179990, 
    stock: 15, 
    stockCritico: 3, 
    categoria: "Accesorios", 
    img: "https://www.cclink.cl/wp-content/uploads/2020/06/Control-%C3%89lite-Series-2-.png"
  },
  { 
    id: 6, 
    codigo: "AC002", 
    nombre: "Auriculares HyperX Cloud Alpha", 
    descripcion: "Audio envolvente 7.1, micrófono con cancelación de ruido, almohadillas de espuma memory foam.", 
    precio: 89990, 
    stock: 20, 
    stockCritico: 5, 
    categoria: "Accesorios", 
    img: "https://row.hyperx.com/cdn/shop/products/hyperx_cloud_alpha_blackred_1_main.jpg?v=1662420668" 
  },
  { 
    id: 7, 
    codigo: "AC003", 
    nombre: "Mouse Logitech G Pro X Superlight", 
    descripcion: "Mouse ultraligero de 63g con sensor HERO 25K, diseño ambidiextro y 70 horas de batería.", 
    precio: 149990, 
    stock: 18, 
    stockCritico: 4, 
    categoria: "Accesorios", 
    img: "https://images.unsplash.com/photo-1527814050087-3793815479db?w=500&h=500&fit=crop" 
  },
  { 
    id: 8, 
    codigo: "AC004", 
    nombre: "Teclado Mecánico Razer BlackWidow V3", 
    descripcion: "Switches mecánicos Green, iluminación RGB Chroma, reposamuñecas ergonómico incluido.", 
    precio: 129990, 
    stock: 14, 
    stockCritico: 3, 
    categoria: "Accesorios", 
    img: "https://assets2.razerzone.com/images/pnx.assets/f83991a174978c3f88c089758ea9fa3c/blackwidow-v3-tenkeyless-usp1-mobile-v2.jpg" 
  },
  { 
    id: 9, 
    codigo: "AC005", 
    nombre: "Mousepad Razer Goliathus Extended", 
    descripcion: "Superficie de tela micro-texturizada, base antideslizante, tamaño XXL (920x294mm).", 
    precio: 39990, 
    stock: 30, 
    stockCritico: 8, 
    categoria: "Accesorios", 
    img: "https://http2.mlstatic.com/D_NQ_NP_2X_816690-MLA84850078563_052025-F.webp" 
  },
  { 
    id: 10, 
    codigo: "AC006", 
    nombre: "Webcam Logitech C920 HD Pro", 
    descripcion: "Video Full HD 1080p a 30fps, corrección de luz automática, micrófonos estéreo duales.", 
    precio: 79990, 
    stock: 12, 
    stockCritico: 3, 
    categoria: "Accesorios", 
    img: "https://i5.walmartimages.com/asr/ca5f2360-1ac1-4ce7-89e8-e08cc0cd8b40_1.3733bb787d5c9d21a2dda386fceba085.jpeg" 
  },

  // JUEGOS DE MESA
  { 
    id: 11, 
    codigo: "JM001", 
    nombre: "Catan", 
    descripcion: "Juego de estrategia clásico. Coloniza la isla, comercia recursos y construye tu civilización.", 
    precio: 34990, 
    stock: 15, 
    stockCritico: 3, 
    categoria: "Juegos de Mesa", 
    img: "https://cdnx.jumpseller.com/magic4ever/image/16617730/Catan-basico-bodegon-web.jpg?1665082693" 
  },
  { 
    id: 12, 
    codigo: "JM002", 
    nombre: "Carcassonne", 
    descripcion: "Construye ciudades medievales colocando losetas y marcando territorios estratégicamente.", 
    precio: 29990, 
    stock: 12, 
    stockCritico: 3, 
    categoria: "Juegos de Mesa", 
    img: "https://www.mastermindtoys.com/cdn/shop/files/carcassonne-game-109412-375077.jpg?v=1742530295" 
  },
  { 
    id: 13, 
    codigo: "JM003", 
    nombre: "Ticket to Ride", 
    descripcion: "Conecta ciudades con rutas de tren en este juego familiar de estrategia y colección.", 
    precio: 39990, 
    stock: 10, 
    stockCritico: 2, 
    categoria: "Juegos de Mesa", 
    img: "https://m.media-amazon.com/images/I/91YNJM4oyhL._AC_SL1500_.jpg"
  },
  { 
    id: 14, 
    codigo: "JM004", 
    nombre: "Pandemic", 
    descripcion: "Juego cooperativo donde trabajan en equipo para salvar al mundo de 4 enfermedades mortales.", 
    precio: 44990, 
    stock: 8, 
    stockCritico: 2, 
    categoria: "Juegos de Mesa", 
    img: "https://cdn.zatu.com/wp-content/uploads/2016/08/18034001/Pandemic-2013.jpg" 
  },

  // PC GAMER
  { 
    id: 15, 
    codigo: "PC001", 
    nombre: "PC Gamer ASUS ROG Strix", 
    descripcion: "Intel i7-13700K, RTX 4070 Ti 12GB, 32GB DDR5, SSD 1TB NVMe. Listo para 4K gaming.", 
    precio: 1899990, 
    stock: 4, 
    stockCritico: 1, 
    categoria: "PC Gamer", 
    img: "https://sipoonline.cl/wp-content/uploads/2024/05/Gabinete-Gamer-ASUS-STRIX-Helios-RGB-GX601-Aluminio-E-ATX_1.png" 
  },
  { 
    id: 16, 
    codigo: "PC002", 
    nombre: "PC Gamer MSI Aegis", 
    descripcion: "AMD Ryzen 9 7900X, RX 7900 XTX 24GB, 64GB DDR5, SSD 2TB. Bestia para streaming y gaming.", 
    precio: 2299990, 
    stock: 2, 
    stockCritico: 1, 
    categoria: "PC Gamer", 
    img: "https://cdn11.bigcommerce.com/s-qnk96/images/stencil/1280x1280/products/1429/7919/81rog_bv1qL._SL1500___13522.1475629114.jpg?c=2" 
  },
  { 
    id: 17, 
    codigo: "PC003", 
    nombre: "PC Gamer Lenovo Legion", 
    descripcion: "Intel i5-13400F, RTX 4060 8GB, 16GB DDR4, SSD 512GB. Perfecto para 1080p gaming.", 
    precio: 999990, 
    stock: 7, 
    stockCritico: 2, 
    categoria: "PC Gamer", 
    img: "https://intercompras.com/images/product/LENOVO_90SV00D2PT.jpg" 
  },

  // SILLAS GAMERS
  { 
    id: 18, 
    codigo: "SG001", 
    nombre: "Silla Secretlab Titan Evo 2022", 
    descripcion: "Cuero NEO Hybrid, ajuste lumbar magnético, reposabrazos 4D, soporta hasta 130kg.", 
    precio: 449990, 
    stock: 6, 
    stockCritico: 2, 
    categoria: "Sillas Gamers", 
    img: "https://m.media-amazon.com/images/I/51y0l8eiBUL._AC_SL1000_.jpg" 
  },
  { 
    id: 19, 
    codigo: "SG002", 
    nombre: "Silla DXRacer Formula Series", 
    descripcion: "Diseño deportivo, respaldo reclinable 135°, espuma de alta densidad, hasta 150kg.", 
    precio: 329990, 
    stock: 8, 
    stockCritico: 2, 
    categoria: "Sillas Gamers", 
    img: "https://cddistribution.com/co/wp-content/uploads/2021/11/MUGCDXR1004-3.jpg" 
  },
  { 
    id: 20, 
    codigo: "SG003", 
    nombre: "Silla Noblechairs EPIC", 
    descripcion: "Cuero PU premium, cilindro de gas clase 4, almohadas incluidas, elegancia y comodidad.", 
    precio: 389990, 
    stock: 5, 
    stockCritico: 1, 
    categoria: "Sillas Gamers", 
    img: "https://media.game.es/COVERV2/3D_L/200/200087.png" 
  },

  // ROPA GAMER
  { 
    id: 21, 
    codigo: "RG001", 
    nombre: "Polera Level-Up Gamer", 
    descripcion: "100% algodón, diseño exclusivo con logo RGB, disponible en negro, blanco y morado.", 
    precio: 19990, 
    stock: 40, 
    stockCritico: 10, 
    categoria: "Ropa Gamer", 
    img: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=500&h=500&fit=crop" 
  },
  { 
    id: 22, 
    codigo: "RG002", 
    nombre: "Hoodie Pro Gamer", 
    descripcion: "Sudadera con capucha, interior polar, bolsillo canguro, estampado gaming premium.", 
    precio: 39990, 
    stock: 25, 
    stockCritico: 6, 
    categoria: "Ropa Gamer", 
    img: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop" 
  },
  { 
    id: 23, 
    codigo: "RG003", 
    nombre: "Gorra Snapback RGB", 
    descripcion: "Gorra ajustable, diseño bordado, visera plana, colores vibrantes.", 
    precio: 14990, 
    stock: 30, 
    stockCritico: 8, 
    categoria: "Ropa Gamer", 
    img: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=500&h=500&fit=crop" 
  }
];

// Seed inicial de usuarios
const SEED_USERS = [
  { id:1, run:"19011022K", nombre:"Admin", apellidos:"Demo", correo:"admin@gmail.com", pass:"1234", tipo:"Administrador", direccion:"Base 123" },
  { id:2, run:"141234560", nombre:"Vendedor", apellidos:"Demo", correo:"vendedor@gmail.com", pass:"1234", tipo:"Vendedor", direccion:"Local 321" },
  { id:3, run:"130000009", nombre:"Cliente", apellidos:"Demo", correo:"cliente@gmail.com", pass:"1234", tipo:"Cliente", direccion:"Casa 456" }
];

// Hook genérico para localStorage
export function useLocalStorage(key, initialValue) {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(error);
    }
  };

  return [storedValue, setValue];
}

// Hook específico para productos
export function useProducts() {
  const [products, setProducts] = useLocalStorage('productosData', SEED_PRODUCTS);
  return [products, setProducts];
}

// Hook específico para usuarios
export function useUsers() {
  const [users, setUsers] = useLocalStorage('usuariosData', SEED_USERS);
  return [users, setUsers];
}

// Hook para sesión de usuario
export function useSession() {
  const [session, setSession] = useLocalStorage('sessionUser', null);
  
  const login = (user) => {
    setSession({
      id: user.id,
      nombre: user.nombre,
      tipo: user.tipo,
      correo: user.correo
    });
  };

  const logout = () => {
    setSession(null);
  };

  return { session, login, logout };
}