import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useLocalStorage } from './useLocalStorage';

describe('useLocalStorage', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('debe inicializar con el valor por defecto', () => {
    const { result } = renderHook(() => useLocalStorage('test-key', 'valor inicial'));
    
    expect(result.current[0]).toBe('valor inicial');
  });

  it('debe guardar y recuperar un valor', () => {
    const { result } = renderHook(() => useLocalStorage('test-key', ''));
    
    act(() => {
      result.current[1]('nuevo valor');
    });
    
    expect(result.current[0]).toBe('nuevo valor');
    expect(localStorage.getItem('test-key')).toBe(JSON.stringify('nuevo valor'));
  });

  it('debe recuperar valor del localStorage si existe', () => {
    localStorage.setItem('test-key', JSON.stringify('valor guardado'));
    
    const { result } = renderHook(() => useLocalStorage('test-key', 'valor inicial'));
    
    expect(result.current[0]).toBe('valor guardado');
  });
});