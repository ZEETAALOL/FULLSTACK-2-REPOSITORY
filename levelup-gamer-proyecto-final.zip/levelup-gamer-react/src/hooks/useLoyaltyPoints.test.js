import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useLoyaltyPoints } from './useLoyaltyPoints';

describe('useLoyaltyPoints', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('debe iniciar sin puntos para un usuario nuevo', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    const points = result.current.getUserPoints(1);
    expect(points).toBe(0);
  });

  it('debe calcular puntos correctamente por compra', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    let earnedPoints;
    act(() => {
      earnedPoints = result.current.addPointsFromPurchase(1, 10000);
    });
    
    expect(earnedPoints).toBe(10);
    expect(result.current.getUserPoints(1)).toBe(10);
  });

  it('debe acumular puntos de múltiples compras', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    act(() => {
      result.current.addPointsFromPurchase(1, 10000); // 10 puntos
    });
    
    act(() => {
      result.current.addPointsFromPurchase(1, 5000);  // 5 puntos
    });
    
    act(() => {
      result.current.addPointsFromPurchase(1, 3000);  // 3 puntos
    });
    
    const points = result.current.getUserPoints(1);
    expect(points).toBe(18);
  });

  it('debe canjear puntos correctamente', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    act(() => {
      result.current.addPointsFromPurchase(1, 100000);
    });
    
    let redeemResult;
    act(() => {
      redeemResult = result.current.redeemPoints(1, 100);
    });
    
    expect(redeemResult.success).toBe(true);
    expect(result.current.getUserPoints(1)).toBe(0);
  });

  it('no debe permitir canjear más puntos de los disponibles', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    act(() => {
      result.current.addPointsFromPurchase(1, 50000);
    });
    
    let redeemResult;
    act(() => {
      redeemResult = result.current.redeemPoints(1, 100);
    });
    
    expect(redeemResult.success).toBe(false);
    expect(result.current.getUserPoints(1)).toBe(50);
  });

  it('debe calcular descuento máximo correctamente', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    act(() => {
      result.current.addPointsFromPurchase(1, 100000);
    });
    
    const maxDiscount = result.current.getMaxDiscount(1);
    const userPoints = result.current.getUserPoints(1);
    
    // 100 puntos = $10,000 descuento
    expect(userPoints).toBe(100);
    expect(maxDiscount).toBe(10000);
  });

  it('debe registrar historial de transacciones', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    act(() => {
      result.current.addPointsFromPurchase(1, 10000);
    });
    
    const history = result.current.getUserHistory(1);
    
    // Debe tener al menos 1 transacción
    expect(history.length).toBeGreaterThanOrEqual(1);
    expect(history[0].type).toBe('earn');
    expect(history[0].points).toBe(10);
  });

  it('puntos deben ser múltiplos de 100 para canjear', () => {
    const { result } = renderHook(() => useLoyaltyPoints());
    
    act(() => {
      result.current.addPointsFromPurchase(1, 150000);
    });
    
    let redeemResult;
    act(() => {
      redeemResult = result.current.redeemPoints(1, 50);
    });
    
    expect(redeemResult.success).toBe(false);
    expect(result.current.getUserPoints(1)).toBe(150);
  });
});