import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminHeader from '../../components/AdminHeader';
import { useUsers, useSession } from '../../hooks/useLocalStorage';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function AdminCompras() {
  const { session } = useSession();
  const navigate = useNavigate();
  const [users] = useUsers();
  const [compras, setCompras] = useState([]);
  const [filtroUsuario, setFiltroUsuario] = useState('');

  useEffect(() => {
    if (!session || session.tipo !== 'Administrador') {
      alert('Acceso restringido. Solo Administradores.');
      navigate('/login');
    }
  }, [session, navigate]);

  useEffect(() => {
    // Cargar historial de compras
    const historial = JSON.parse(localStorage.getItem('historialCompras')) || [];
    setCompras(historial.sort((a, b) => new Date(b.fecha) - new Date(a.fecha)));
  }, []);

  const getUsuarioNombre = (userId) => {
    const user = users.find(u => u.id === userId);
    return user ? `${user.nombre} ${user.apellidos} (${user.correo})` : `Usuario ID: ${userId}`;
  };

  const comprasFiltradas = filtroUsuario
    ? compras.filter(c => c.userId === parseInt(filtroUsuario))
    : compras;

  const totalVentas = comprasFiltradas.reduce((sum, c) => sum + c.total, 0);

  if (!session) return null;

  return (
    <div className="admin">
      <AdminHeader />
      <main className="section">
        <h1 className="section-title">📦 Historial de Compras</h1>

        {/* Estadísticas */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '20px',
          marginBottom: '30px'
        }}>
          <div className="info-card">
            <div style={{ fontSize: '2em', marginBottom: '10px' }}>🛒</div>
            <div style={{ fontSize: '1.8em', fontWeight: 'bold', color: 'var(--primary)' }}>
              {comprasFiltradas.length}
            </div>
            <div style={{ color: 'rgba(255,255,255,0.7)' }}>Total Compras</div>
          </div>
          <div className="info-card">
            <div style={{ fontSize: '2em', marginBottom: '10px' }}>💰</div>
            <div style={{ fontSize: '1.5em', fontWeight: 'bold', color: 'var(--accent-2)' }}>
              {CLP.format(totalVentas)}
            </div>
            <div style={{ color: 'rgba(255,255,255,0.7)' }}>Total Ventas</div>
          </div>
          <div className="info-card">
            <div style={{ fontSize: '2em', marginBottom: '10px' }}>👥</div>
            <div style={{ fontSize: '1.8em', fontWeight: 'bold', color: 'var(--accent)' }}>
              {new Set(comprasFiltradas.map(c => c.userId)).size}
            </div>
            <div style={{ color: 'rgba(255,255,255,0.7)' }}>Clientes Únicos</div>
          </div>
        </div>

        {/* Filtro de usuario */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{
            display: 'block',
            marginBottom: '8px',
            fontWeight: '600',
            color: 'var(--primary)'
          }}>
            Filtrar por usuario:
          </label>
          <select
            value={filtroUsuario}
            onChange={(e) => setFiltroUsuario(e.target.value)}
            style={{
              padding: '10px',
              borderRadius: '8px',
              border: '2px solid rgba(189, 46, 255, 0.3)',
              background: 'var(--card)',
              color: '#fff',
              fontSize: '1em',
              width: '100%',
              maxWidth: '400px'
            }}
          >
            <option value="">Todos los usuarios</option>
            {users.map(u => (
              <option key={u.id} value={u.id}>
                {u.nombre} {u.apellidos} - {u.correo}
              </option>
            ))}
          </select>
        </div>

        {/* Tabla de compras */}
        {comprasFiltradas.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
            <p>No hay compras registradas</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Fecha</th>
                  <th>Usuario</th>
                  <th>Items</th>
                  <th>Total</th>
                  <th>Descuento DUOC</th>
                  <th>Descuento Puntos</th>
                  <th>Detalles</th>
                </tr>
              </thead>
              <tbody>
                {comprasFiltradas.map((compra) => (
                  <tr key={compra.id}>
                    <td>{compra.id}</td>
                    <td>{new Date(compra.fecha).toLocaleString('es-CL')}</td>
                    <td>{getUsuarioNombre(compra.userId)}</td>
                    <td style={{ textAlign: 'center' }}>{compra.items}</td>
                    <td style={{ color: 'var(--accent-2)', fontWeight: 'bold' }}>
                      {CLP.format(compra.total)}
                    </td>
                    <td style={{ color: compra.descuentoDuoc > 0 ? '#f39c12' : 'rgba(255,255,255,0.5)' }}>
                      {compra.descuentoDuoc > 0 ? CLP.format(compra.descuentoDuoc) : '-'}
                    </td>
                    <td style={{ color: compra.descuentoPuntos > 0 ? '#00d4ff' : 'rgba(255,255,255,0.5)' }}>
                      {compra.descuentoPuntos > 0 ? CLP.format(compra.descuentoPuntos) : '-'}
                    </td>
                    <td>
                      <details>
                        <summary style={{ cursor: 'pointer', color: 'var(--primary)' }}>
                          Ver productos
                        </summary>
                        <div style={{ marginTop: '10px', padding: '10px', background: 'rgba(0,0,0,0.3)', borderRadius: '8px' }}>
                          {compra.productos.map((prod, idx) => (
                            <div key={idx} style={{ padding: '5px 0', borderBottom: idx < compra.productos.length - 1 ? '1px solid #333' : 'none' }}>
                              <strong>{prod.nombre}</strong><br />
                              <small>Cantidad: {prod.cantidad} × {CLP.format(prod.precio)}</small>
                            </div>
                          ))}
                          {compra.direccion && (
                            <div style={{ marginTop: '10px', paddingTop: '10px', borderTop: '1px solid #333' }}>
                              <strong>Dirección de envío:</strong><br />
                              <small>{compra.direccion}</small>
                            </div>
                          )}
                        </div>
                      </details>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}

export default AdminCompras;
