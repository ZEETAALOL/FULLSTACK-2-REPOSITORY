import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Boleta from '../components/Boleta';
import { useSession } from '../hooks/useLocalStorage';
import { useLoyaltyPoints } from '../hooks/useLoyaltyPoints';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function Perfil() {
  const { session } = useSession();
  const navigate = useNavigate();
  const { getUserPoints, getUserHistory } = useLoyaltyPoints();
  const [selectedBoleta, setSelectedBoleta] = useState(null);

  // Redirigir si no hay sesión (protección inicial y cuando se desloguea)
  useEffect(() => {
    if (!session) {
      navigate('/login');
    }
  }, [session, navigate]);

  // Escuchar cambios en el localStorage para detectar logout
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === 'sessionUser' && e.newValue === null) {
        navigate('/login');
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // También escuchar evento personalizado de logout
    const handleLogout = () => {
      navigate('/login');
    };

    window.addEventListener('userLogout', handleLogout);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('userLogout', handleLogout);
    };
  }, [navigate]);

  if (!session) return null;

  const userPoints = getUserPoints(session.id);
  const history = getUserHistory(session.id);

  // Obtener historial de compras desde localStorage
  const getComprasHistorial = () => {
    const compras = JSON.parse(localStorage.getItem('historialCompras')) || [];
    return compras.filter(c => c.userId === session.id);
  };

  const compras = getComprasHistorial();

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">👤 Mi Perfil</h1>

        {/* Información del Usuario */}
        <div className="card" style={{ maxWidth: '800px', margin: '0 auto 30px' }}>
          <h2 style={{ marginBottom: '20px', color: 'var(--primary)' }}>
            Información Personal
          </h2>
          <div style={{ display: 'grid', gap: '15px' }}>
            <div>
              <strong>Nombre:</strong> {session.nombre}
            </div>
            <div>
              <strong>Correo:</strong> {session.correo}
            </div>
            <div>
              <strong>Tipo de usuario:</strong> {session.tipo}
            </div>
            <div>
              <strong>Puntos acumulados:</strong> 
              <span style={{ color: 'var(--primary)', fontSize: '1.2em', marginLeft: '10px' }}>
                💎 {userPoints} pts
              </span>
            </div>
          </div>
        </div>

        {/* Historial de Compras */}
        <div className="card" style={{ maxWidth: '800px', margin: '0 auto' }}>
          <h2 style={{ marginBottom: '20px', color: 'var(--primary)' }}>
            📦 Historial de Compras
          </h2>
          {compras.length === 0 ? (
            <p style={{ color: 'rgba(255,255,255,0.6)', textAlign: 'center', padding: '40px' }}>
              No has realizado compras aún
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              {compras.slice(0).reverse().map((compra, index) => (
                <div
                  key={index}
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    padding: '20px',
                    borderRadius: '12px',
                    border: '1px solid rgba(189, 46, 255, 0.3)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                    <div>
                      <strong style={{ fontSize: '1.1em' }}>Compra #{compra.id}</strong>
                      <div style={{ fontSize: '0.9em', color: 'rgba(255,255,255,0.7)', marginTop: '5px' }}>
                        {new Date(compra.fecha).toLocaleString('es-CL', {
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '1.3em', fontWeight: 'bold', color: 'var(--primary)' }}>
                        {CLP.format(compra.total)}
                      </div>
                      <button
                        onClick={() => setSelectedBoleta(compra)}
                        style={{
                          marginTop: '10px',
                          background: 'var(--gradient-1)',
                          color: '#fff',
                          border: 'none',
                          padding: '8px 16px',
                          borderRadius: '8px',
                          cursor: 'pointer',
                          fontSize: '0.9em',
                          fontWeight: '600',
                          transition: 'all 0.2s ease'
                        }}
                        onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
                        onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
                      >
                        🖨️ Ver Boleta
                      </button>
                    </div>
                  </div>

                  {/* Detalle de productos */}
                  <div style={{
                    background: 'rgba(0,0,0,0.2)',
                    padding: '15px',
                    borderRadius: '8px',
                    marginTop: '10px'
                  }}>
                    <div style={{ fontWeight: '600', marginBottom: '10px', color: 'var(--accent-2)' }}>
                      📦 Productos ({compra.productos?.length || 0}):
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {compra.productos?.map((prod, idx) => (
                        <div
                          key={idx}
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            padding: '8px',
                            background: 'rgba(255,255,255,0.03)',
                            borderRadius: '6px',
                            fontSize: '0.9em'
                          }}
                        >
                          <span>
                            <strong>{prod.nombre}</strong> × {prod.cantidad}
                          </span>
                          <span style={{ color: 'var(--accent-2)' }}>
                            {CLP.format(prod.precio * prod.cantidad)}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Descuentos aplicados */}
                    {(compra.descuentoDuoc > 0 || compra.descuentoPuntos > 0) && (
                      <div style={{ marginTop: '10px', paddingTop: '10px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                        {compra.descuentoDuoc > 0 && (
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9em', color: '#f39c12' }}>
                            <span>🎓 Descuento DUOC (20%):</span>
                            <span>-{CLP.format(compra.descuentoDuoc)}</span>
                          </div>
                        )}
                        {compra.descuentoPuntos > 0 && (
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9em', color: '#00d4ff', marginTop: '5px' }}>
                            <span>💎 Descuento Puntos:</span>
                            <span>-{CLP.format(compra.descuentoPuntos)}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Dirección de envío */}
                    {compra.direccion && (
                      <div style={{ marginTop: '10px', paddingTop: '10px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                        <div style={{ fontSize: '0.85em', color: 'rgba(255,255,255,0.6)' }}>
                          📍 <strong>Dirección de envío:</strong> {compra.direccion}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Historial de Puntos */}
        <div className="card" style={{ maxWidth: '800px', margin: '30px auto 0' }}>
          <h2 style={{ marginBottom: '20px', color: 'var(--primary)' }}>
            💎 Historial de Puntos
          </h2>
          {history.length === 0 ? (
            <p style={{ color: 'rgba(255,255,255,0.6)', textAlign: 'center', padding: '40px' }}>
              No tienes movimientos de puntos aún
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {history.slice(0, 10).map((transaction) => (
                <div 
                  key={transaction.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '12px',
                    background: transaction.type === 'earn' 
                      ? 'rgba(0,255,0,0.05)' 
                      : 'rgba(255,0,0,0.05)',
                    borderRadius: '8px',
                    border: `1px solid ${transaction.type === 'earn' ? 'rgba(0,255,0,0.2)' : 'rgba(255,0,0,0.2)'}`
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '0.9em' }}>{transaction.description}</div>
                    <div style={{ fontSize: '0.8em', color: 'rgba(255,255,255,0.5)', marginTop: '5px' }}>
                      {new Date(transaction.date).toLocaleDateString('es-CL')}
                    </div>
                  </div>
                  <div style={{ 
                    fontSize: '1.1em', 
                    fontWeight: 'bold',
                    color: transaction.type === 'earn' ? '#00ff00' : '#ff4444'
                  }}>
                    {transaction.points > 0 ? '+' : ''}{transaction.points} pts
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />

      {/* Modal de Boleta */}
      {selectedBoleta && (
        <Boleta
          compra={selectedBoleta}
          usuario={session}
          onClose={() => setSelectedBoleta(null)}
        />
      )}
    </>
  );
}

export default Perfil;
